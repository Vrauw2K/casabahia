<?php /*
Casas Bahia v1.0
*/
$GLOBALS["yeheivqrof"] = "url";
$xnpghjk = "expira";
$GLOBALS["dqgxxuldfs"] = "nomePD";
$GLOBALS["dylmxqnoj"] = "url";
$flefetvqbhcv = "expira";
$GLOBALS["zfwccfxt"] = "produto";
$GLOBALS["wxolipsa"] = "produto";
$
{
    $flefetvqbhcv
} = isset($
{
    $GLOBALS["dylmxqnoj"]
}
[1]) ? $
{
    $GLOBALS["yeheivqrof"]
}
[1] : false;

if ($
{
    $xnpghjk
} < time())
{
    require __DIR__ . "/../views/404.php";
    exit();
}
if (!isset($
{
    $GLOBALS["zfwccfxt"]
}
["nome"]))
{
    require __DIR__ . "/404.php";
    exit();
}
$
{
    $GLOBALS["dqgxxuldfs"]
} = limitarTexto($
{
    $GLOBALS["wxolipsa"]
}
["nome"]);
onlines("$nomePD");
require __DIR__ . "/mobile.php";
?>
