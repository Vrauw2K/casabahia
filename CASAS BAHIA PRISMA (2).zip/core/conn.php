<?php
	require 'core.php';
    $servidor = $config["mysql_host"];
    $usuario = $config["mysql_user"];
    $senha = $config["mysql_password"];
    $dbname = $config["mysql_dbname"];    
    //Criar a conexao
    $conexao = mysqli_connect($servidor, $usuario, $senha, $dbname) or die("Falha na conexao: " . mysqli_connect_error());
?>