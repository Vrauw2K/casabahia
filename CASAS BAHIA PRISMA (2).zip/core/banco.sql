/*
 Navicat MySQL Data Transfer

 Source Server         : Smart PRO
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : localhost:3306
 Source Schema         : _casasbahia

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 17/04/2021 05:03:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bancos
-- ----------------------------
DROP TABLE IF EXISTS `bancos`;
CREATE TABLE `bancos`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `3dig` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `digitos` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `banco` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of bancos
-- ----------------------------
INSERT INTO `bancos` VALUES (1, '121', '121-0', 'agibank', 'Agi Bank');
INSERT INTO `bancos` VALUES (2, '212', '212', 'original', 'Original');
INSERT INTO `bancos` VALUES (3, '655', '655', 'neon', 'Neon');
INSERT INTO `bancos` VALUES (4, '422', '422-7', 'safra', 'Safra');
INSERT INTO `bancos` VALUES (5, '237', '237-2', 'bradesco', 'Bradesco');
INSERT INTO `bancos` VALUES (6, '341', '341-7', 'itau', 'Itau');
INSERT INTO `bancos` VALUES (7, '033', '033-7', 'santander', 'Santander');
INSERT INTO `bancos` VALUES (8, '001', '001-9', 'bancodobrasil', 'Banco do Brasil');
INSERT INTO `bancos` VALUES (9, '104', '104-0', 'caixa', 'Caixa Economica Federal');
INSERT INTO `bancos` VALUES (10, '077', '077-9', 'inter', 'Intermedium');

-- ----------------------------
-- Table structure for bia
-- ----------------------------
DROP TABLE IF EXISTS `bia`;
CREATE TABLE `bia`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `sac` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `send` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `dont` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `business` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of bia
-- ----------------------------

-- ----------------------------
-- Table structure for bin
-- ----------------------------
DROP TABLE IF EXISTS `bin`;
CREATE TABLE `bin`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `bin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `banco` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contato` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lvl` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `versao` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cclvl` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '1',
  `vbv` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `cbc` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `img` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `destaque` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `digitos` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '4',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 469 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of bin
-- ----------------------------
INSERT INTO `bin` VALUES (1, '422053', 'Bradesco S.A', '4003-4033', 'Classic', 'visa', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (2, '541465', 'Bradesco S.A', '4004-4545', 'Gold', 'mastercard', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (3, '415274', 'Porto Seguro S.A', '4004-3600', 'Gold', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (4, '412177', 'Porto Seguro S.A', '4004-3600', 'Classic', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (5, '415275', 'Porto Seguro S.A', '4004-3600', 'Platinum', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (14, '427167', 'Bradesco S.A', '4003-4033', 'Classic', 'visa', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (15, '522590', 'Sicredi S.A', '3003 4770', 'Gold', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (18, '498442', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (19, '528392', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (20, '455183', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (21, '432032', 'HSBC Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (22, '422100', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (23, '544731', 'Santander S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (24, '530034', 'Carrefour S.A', '', 'Standard', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (25, '428267', 'IBI S.A', '4004-1022', 'Classic', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (26, '422005', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (27, '464299', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (28, '509000', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (29, '455187', 'Bradesco S.A', '', 'Business', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (30, '541187', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (31, '535081', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (32, '455181', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (33, '535858', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (34, '535088', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (35, '418053', 'IBI S.A', '4004-1022', 'Classic', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (36, '459060', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (37, '526778', 'Bradesco S.A', '4004 7332', 'Titanium', 'mastercard', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (38, '410424', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (39, '400654', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (40, '410863', 'Santander S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (41, '531705', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (42, '518950', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (43, '438006', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (44, '530780', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (45, '439354', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (46, '518544', 'Bradesco S.A', '4004-7332', 'Standard', 'mastercard', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (47, '545719', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (48, '498401', 'Banco do Brasil S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (49, '506728', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (50, '514086', 'Panamericano S.A', '4003-0101', 'Standard', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (51, '548573', 'Banco do Brasil S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (52, '400689', 'CrediCard S.A', '', 'Classic', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (53, '400770', 'Caixa Economica Federal', '4004-9009', 'Classic', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (54, '520405', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (55, '506775', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (56, '409600', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (57, '650494', 'Bradesco S.A', '', 'Elo', 'Personal', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (58, '439390', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (59, '548046', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (60, '546479', 'Banco do Brasil S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (61, '422463', 'IBI S.A', '', 'Classic', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (62, '520359', 'BANCO CBSS SA', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (63, '421379', 'Bradesco S.A', '4004 7332', 'Classic', 'visa', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (64, '525663', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (65, '536380', 'Porto Seguro S.A', '4004-3600', 'Standard', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (66, '548724', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (67, '525320', 'Itau S.A', '', 'Mastercard Eletron', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (68, '525922', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (69, '627780', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (70, '606282', 'Itau S.A', '', 'HiperCard', 'hiper', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (71, '400185', 'Banco do Brasil S.A', '', 'Debito', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (72, '522499', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (73, '544828', 'Citibank S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (74, '459360', 'Caixa Economica Federal', '', 'Classic', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (75, '455184', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (76, '400475', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (77, '512707', 'Sicoob S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (78, '540593', 'Caixa Economica Federal', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (79, '506727', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (80, '520898', 'Panamericano S.A', '', 'Standard', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (81, '506776', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (82, '459313', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (83, '471703', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (84, '521180', 'Santander S.A', '', 'MasterCard Eletron', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (85, '527497', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (86, '544315', 'Renner S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (87, '525496', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (88, '462068', 'BRASIL PREPAGOS', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (89, '550209', 'NuBank S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (90, '421848', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (91, '627892', 'Maestro', '', 'Maestro', 'Debito', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (92, '526863', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (93, '514087', 'Bradesco S.A', '4004-7332', 'Standard', 'mastercard', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (94, '549585', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (95, '516292', 'NuBank S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (96, '535016', 'Avista S.A', '3003 3210', 'Standard', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (97, '506731', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (98, '541759', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (99, '542820', 'Santander S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (100, '498453', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (101, '552937', 'Caixa Economica Federal', '4004-9001', 'Platinum', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (102, '530033', 'Carrefour S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (103, '523421', 'NuBank S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (104, '464294', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (105, '498406', 'Banco do Brasil S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (106, '543299', 'UNIK', '', 'Pre Pago', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (107, '548985', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (108, '524820', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (109, '483066', 'Panamericano S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (110, '650485', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (111, '457305', 'IBI S.A', '4004-1022', 'Gold', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (112, '528635', 'Pernambucanas S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (113, '498423', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (114, '534503', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (115, '536492', 'Bradesco S.A', '4004-7332', 'Standard', 'mastercard', '2', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (116, '471233', 'Banco do Nordeste S.A', '', 'Debito', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (117, '527496', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (118, '536518', 'Midway S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (119, '482425', 'Midway S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (120, '530994', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (121, '516220', 'NuBank S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (122, '420338', 'IBI S.A', '4004-1022', 'Classic', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (123, '525664', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (124, '498582', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (125, '554463', 'Banrisul S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (126, '636760', 'Cartao Corporativo Privado', '', 'Privado', 'PRIVATE LABEL CARD', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (127, '403246', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (128, '520156', 'BANCO DE BRASILIA S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (129, '549319', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (130, '476333', 'Sicredi S.A', '3003-4770', 'Classic', 'visa', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (131, '548723', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (132, '515590', 'Santander S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (133, '455182', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (134, '512682', 'Caixa Economica Federal', '4004 9009', 'Standard', 'mastercard', '2', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (135, '636368', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (136, '546452', 'Banco do Brasil S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (137, '541555', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (138, '515787', 'Caixa Economica Federal', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (139, '419597', 'NuBank S.A', '', 'Gold', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (140, '422200', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (141, '409603', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (142, '554865', 'NuBank S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (143, '407303', 'Banco Real', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (144, '459384', 'Caixa Economica Federal', '', 'Gold', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (145, '554927', 'Banco do Brasil S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (146, '434949', 'Carrefour S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (147, '514945', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (148, '523284', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (149, '527468', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (150, '453211', 'Bradesco S.A', '', 'Gold', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (151, '549391', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (152, '650516', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (153, '428269', 'IBI S.A', '', 'Gold', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (154, '521509', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (155, '531681', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (156, '516230', 'NuBank S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (157, '518454', 'Votorantim S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (158, '439267', 'Caixa Economica Federal', '', 'Visa Eletron', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (159, '528052', 'Santander S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (160, '529861', 'Avista S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (161, '400437', 'HSBC Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (162, '543882', 'Cartao Atacadao', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (163, '421845', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (164, '434995', 'Leader', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (165, '527437', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (166, '400439', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (167, '512427', 'Bradesco S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (168, '529323', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (169, '451476', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (170, '428304', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (171, '585988', 'NULL', '', 'Standard', 'Maestro Debit', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (172, '438028', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (174, '406897', 'Panamericano S.A', NULL, 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (175, '406669', 'Bradesco S.A', NULL, 'Infinite', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (176, '527407', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (177, '522840', 'Santander S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (178, '459078', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (179, '376486', 'American Express', '', 'Standard', 'amex', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (180, '525662', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (181, '515894', 'Sicoob S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (182, '542974', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (183, '406168', 'Carrefour S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (184, '476608', 'BCN S.A', '', 'Standard', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (185, '441524', 'Santander S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (186, '459020', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (187, '517756', 'Santander S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (188, '418668', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (189, '419625', 'Santander S.A', '', 'Standard', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (190, '406655', 'Bradesco S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (191, '545462', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (192, '518313', 'Banco União Brasil S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (193, '400163', 'Banco do Brasil S.A', '', 'Debito', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (194, '418049', 'IBI S.A', '4004-1022', 'Classic', 'visa', '2', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (195, '506741', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (196, '438002', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (197, '554906', 'Banco do Brasil S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (198, '546056', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (199, '521043', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (200, '512363', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (201, '539028', 'Citibank S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (202, '376524', 'American Express', '', 'Standard', 'amex', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (203, '554473', 'Banrisul S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (204, '548984', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (205, '476331', 'Sicredi S.A', '', 'Gold', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (206, '498407', 'Banco do Brasil S.A', '', 'Gold', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (207, '514004', 'IBI S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (208, '539068', 'BANCO CITICARD S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (209, '400248', 'BANCO CITICARD S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (210, '491674', 'BANCO ABN AMRO REAL S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (211, '422023', 'CREDIARE S.A. CREDITO FINANCIAMENTO E INVESTIMENTO', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (212, '400225', 'Citibank S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (213, '552305', 'Bradesco S.A', '', 'Black', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (214, '546852', 'Banrisul S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (215, '430535', 'Banrisul S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (216, '548474', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (217, '527533', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (218, '539073', 'BANCO CITICARD S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (219, '539029', 'BANCO CITICARD S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (220, '402702', 'BANCO BONSUCESSO, S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (221, '498431', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (222, '512374', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (223, '444456', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (224, '539091', 'CrediCard S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (225, '558763', 'Caixa Economica Federal', '', 'Corporativo', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (226, '411804', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (227, '520184', 'Santander S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (228, '547408', 'Sicoob S.A', '', 'Business', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (229, '470598', 'Itau S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (230, '409601', 'BV Financeira S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (231, '518814', 'Votorantim S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (232, '548827', 'Caixa Economica Federal', '', 'Gold', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (233, '428268', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (234, '376466', 'Bradesco S.A', '', 'American Expres', 'amex', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (235, '412791', 'BRB-BANCO DE BRASILIA, S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (236, '544891', 'CrediCard S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (237, '432031', 'HSBC Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (238, '467149', 'BANCO FININVEST, S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (239, '439389', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (240, '534520', 'Sicredi S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (241, '628028', 'Maestro', '', 'Debio', 'Maestro', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (242, '535097', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (243, '506722', 'Elo S.A', '', 'Multiplo', 'elo', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (244, '515117', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (245, '534447', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (246, '423944', 'HSBC Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (247, '515118', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (248, '506726', 'Banco do Brasil S.A', '', 'Debito', 'elo', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (249, '639664', 'Banrisul S.A', '', 'Standard', 'Maestro Debito', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (250, '459314', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (251, '535850', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (252, '493100', 'Bradesco S.A', '', 'Gold', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (253, '400970', 'Caixa Economica Federal', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (254, '553096', 'Caixa Economica Federal', '', 'Business', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (255, '455185', 'Bradesco S.A', '', 'Business', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (256, '552128', 'Citibank S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (257, '422061', 'Santander S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (258, '376464', 'Bradesco S.A', '', 'American Expres', 'amex', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (259, '467148', 'BANK OF AMERICA', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (260, '490172', 'Itau S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (261, '549159', 'Bradesco S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (262, '527889', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (263, '473200', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (264, '444458', 'Banco do Brasil S.A', '', 'Gold', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (265, '514868', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (266, '479395', 'Caixa Economica Federal', '', 'Platinum', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (267, '419620', 'Santander S.A', '', 'Standard', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (268, '527495', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (269, '498408', 'Banco do Brasil S.A', '', 'Infinite', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (270, '430963', 'Santander S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (271, '489391', 'Itau S.A', '', 'Platinum', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (272, '376478', 'American Express', '', 'Standard', 'amex', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (273, '515601', 'Sicoob S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (274, '401370', 'Caixa Economica Federal', '', 'Gold', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (275, '518767', 'Caixa Economica Federal', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (276, '548826', 'Caixa Economica Federal', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (277, '419623', 'Santander S.A', '', 'Standard', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (278, '491411', 'Banrisul S.A', '', 'Gold', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (279, '549368', 'BANCO CITICARD S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (280, '544540', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (281, '376491', 'American Express', '', 'Standard', 'amex', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (282, '549167', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (283, '539090', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (284, '422185', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (285, '548293', 'Bradesco S.A', '', 'Gold', 'mastercard', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (286, '544915', 'Banrisul S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (287, '459077', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (288, '539003', 'CrediCard S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (289, '518482', 'Votorantim S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (290, '422012', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '4');
INSERT INTO `bin` VALUES (291, '498424', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (292, '417987', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (293, '459450', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (294, '439013', 'Mercantil do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (295, '518277', 'BANCO TRIANGULO S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (296, '540105', 'Santander S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (297, '553636', 'Itau S.A', '', 'Black', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (298, '552236', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (299, '444054', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (300, '441120', 'Santander S.A', '', 'Gold', 'visa', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (301, '552693', 'Santander S.A', '', 'Business', 'mastercard', '1', '0', '0', '', '2', '6');
INSERT INTO `bin` VALUES (302, '463312', 'BANCO ABN AMRO REAL S.A', '', 'Classic', 'visa', '1', '0', '0', '', '0', '4');
INSERT INTO `bin` VALUES (303, '438008', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', '', '3', '6');
INSERT INTO `bin` VALUES (304, '520402', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', '', '2', '4');
INSERT INTO `bin` VALUES (305, '444457', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', '', '1', '6');
INSERT INTO `bin` VALUES (306, '524703', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (307, '458919', 'Digio', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (308, '509042', 'Caixa Economica Federal', '', 'ELO MAIS', 'elo', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (309, '496045', 'Sicredi S.A', '', 'BUSINESS', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (310, '534593', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (311, '533728', 'PagBank', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (312, '545377', 'HUB CARD S.A.', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (313, '472280', 'NULL', '', 'Gold', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (314, '402934', 'NULL', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (315, '548045', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (316, '459383', 'Caixa Economica Federal', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (317, '520132', 'Santander S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '2', '6');
INSERT INTO `bin` VALUES (318, '459080', 'Itau S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (319, '477250', 'Votorantim S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (320, '513557', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (321, '406263', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (322, '650491', 'Bradesco S.A', '', 'Elo', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (323, '528599', 'Votorantim S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (324, '422004', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (325, '650487', 'Banco do Brasil S.A', '', 'Discovery', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (326, '400268', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (327, '529867', 'UNIK', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (328, '400178', 'Banco do Brasil S.A', '', 'Debito', 'visa', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (329, '485464', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (330, '409602', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (331, '506721', 'Banco do Brasil S.A', '', 'Classic', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (332, '491412', 'Banrisul S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (333, '474525', 'Renner S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (334, '509091', 'Bradesco S.A', '', 'Classic', 'elo', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (335, '410715', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (336, '650507', 'Caixa Economica Federal', '', 'PERSONAL', 'elo', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (337, '527887', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (338, '520977', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (339, '536537', 'Porto Seguro S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (340, '420340', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (341, '527680', 'Sicredi S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (342, '655001', 'Banco do Brasil S.A', '', 'Discovery', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (343, '421964', 'Caixa Economica Federal', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (344, '438016', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (345, '604338', 'CABAL CARTAO', '', 'NULL', 'LOCAL BRAND', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (346, '489167', 'EMPORIKI BANK', '', 'Platinum', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (347, '539039', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (348, '650725', 'DISPONIVEL', '', 'PERSONAL', 'DISCOVER', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (349, '516283', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (350, '542661', 'Banco do Brasil S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (351, '521397', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (352, '493103', 'Bradesco S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (353, '376481', 'Bradesco S.A', '', 'AMERICAN EXPRES', 'amex', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (354, '511588', 'Agibank S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (355, '421958', 'Caixa Economica Federal', '', 'Platinum', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (356, '502121', 'NULL', '', 'Debito', 'MAESTRO', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (357, '456137', 'Itau S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (358, '530998', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (359, '511623', 'HUB CARD S.A.', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (360, '493101', 'Bradesco S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (361, '544199', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (362, '526769', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (363, '506730', 'Banco do Brasil S.A', '', 'Business', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (364, '650042', 'Bradesco S.A', '', 'Elo', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (365, '526787', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (366, '522688', 'NULL', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (367, '474512', 'Santander S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '6');
INSERT INTO `bin` VALUES (368, '412793', 'BRB-BANCO DE BRASILIA, S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (369, '526326', 'NULL', '', 'NULL', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (370, '520363', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (371, '439388', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (372, '459315', 'Itau S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (373, '542976', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (374, '655003', 'Banco do Brasil S.A', '', 'Discovery', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (375, '527462', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (376, '421962', 'Caixa Economica Federal', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (377, '432958', 'NULL', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (378, '532930', 'Porto Seguro S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (379, '549359', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (380, '518745', 'NULL', '', 'NULL', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (381, '464300', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (382, '589916', 'NULL', '', 'NULL', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (383, '424694', 'NULL', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (384, '477272', 'Votorantim S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (385, '526549', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (386, '491675', 'Santander S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '2', '6');
INSERT INTO `bin` VALUES (387, '650486', 'Bradesco S.A', '', 'Elo', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (388, '460034', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (389, '516306', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (390, '510147', 'Bradesco S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (391, '650488', 'Bradesco S.A', '', 'Elo', 'elo', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (392, '427164', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (393, '422201', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (394, '524314', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (395, '404025', 'NULL', '', 'Debito', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (396, '534540', 'BANCO ORIGINAL', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (397, '451342', 'Banestes S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (398, '438022', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (399, '434639', 'Panamericano S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (400, '483042', 'Bradesco S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (401, '498496', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '6');
INSERT INTO `bin` VALUES (402, '527789', 'Super Digital', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (403, '463294', 'Itau S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (406, '536143', 'Itau S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (407, '468210', 'Banrisul S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (408, '466069', 'Sicoob S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (409, '459380', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (410, '534513', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (411, '376526', 'Bradesco S.A', '', 'American Expres', 'amex', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (412, '552640', 'Itau S.A', '', 'Business', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (413, '539083', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '2', '4');
INSERT INTO `bin` VALUES (414, '375177', 'Bradesco S.A', '', 'American Expres', 'amex', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (415, '536832', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (416, '403406', 'Carrefour S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (417, '403407', 'Carrefour S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (418, '406166', 'Carrefour S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (419, '406167', 'Carrefour S.A', '', 'Pre-Pago', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (420, '540216', 'Carrefour S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (421, '543104', 'Carrefour S.A', '', 'Classic', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (422, '544824', 'Carrefour S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (423, '545452', 'Carrefour S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (424, '559917', 'Carrefour S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (425, '516376', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (426, '517973', 'BMG S.A', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (427, '525923', 'BMG S.A', '', 'Debito', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (428, '527451', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (429, '529479', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (430, '531304', 'BMG S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (431, '531566', 'BMG S.A', '', 'Platinum', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (432, '536833', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (433, '541143', 'BMG S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (434, '542421', 'BMG S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (435, '548199', 'BMG S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (436, '550159', 'BMG S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (437, '553492', 'BMG S.A', '', 'Corporativo', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (438, '554464', 'BMG S.A', '', 'Pre-Pago', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (439, '557793', 'BMG S.A', '', 'Classic', 'mastercard', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (440, '412122', 'BMG S.A', '', 'Pre-Pago', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (441, '402942', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (442, '402947', 'BV Financeira S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (443, '403002', 'BV Financeira S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (444, '409007', 'BV Financeira S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (445, '425890', 'BV Financeira S.A', '', 'Infinite', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (446, '445015', 'BV Financeira S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (447, '446122', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (448, '459006', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (449, '459379', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (450, '477243', 'BV Financeira S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (451, '477244', 'BV Financeira S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (452, '482455', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (453, '482456', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (454, '482457', 'BV Financeira S.A', '', 'Gold', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (455, '482458', 'BV Financeira S.A', '', 'Platinum', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (456, '409921', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (457, '409922', 'BV Financeira S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (458, '439276', 'Bradesco S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '3', '6');
INSERT INTO `bin` VALUES (459, '525718', 'Itau S.A', '', 'Gold', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (460, '444434', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '6');
INSERT INTO `bin` VALUES (461, '471701', 'Banco do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '6');
INSERT INTO `bin` VALUES (462, '421365', 'IBI S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '1', '4');
INSERT INTO `bin` VALUES (463, '522027', 'Itau S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (464, '554773', 'BANCO DE BRASILIA S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (465, '522815', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (466, '525631', 'Cetelem S.A', '', 'Standard', 'mastercard', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (467, '411854', 'Banestes S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');
INSERT INTO `bin` VALUES (468, '439020', 'Mercantil do Brasil S.A', '', 'Classic', 'visa', '1', '0', '0', NULL, '0', '4');

-- ----------------------------
-- Table structure for blacklist
-- ----------------------------
DROP TABLE IF EXISTS `blacklist`;
CREATE TABLE `blacklist`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of blacklist
-- ----------------------------

-- ----------------------------
-- Table structure for boletos
-- ----------------------------
DROP TABLE IF EXISTS `boletos`;
CREATE TABLE `boletos`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `linha` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `produto_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gerado` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `pago` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `vencimento` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `vencido` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21031 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of boletos
-- ----------------------------

-- ----------------------------
-- Table structure for configs
-- ----------------------------
DROP TABLE IF EXISTS `configs`;
CREATE TABLE `configs`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `dias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cards` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `multiples_access` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pedido` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `authy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `rwite` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ip_show` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of configs
-- ----------------------------
INSERT INTO `configs` VALUES (1, '1', '', '1', '1', '0', '0', '0', 'ligth', '1');

-- ----------------------------
-- Table structure for contador
-- ----------------------------
DROP TABLE IF EXISTS `contador`;
CREATE TABLE `contador`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `ccs` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `boletos` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `onlines` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of contador
-- ----------------------------
INSERT INTO `contador` VALUES (1, '0', '0', '0');

-- ----------------------------
-- Table structure for dados
-- ----------------------------
DROP TABLE IF EXISTS `dados`;
CREATE TABLE `dados`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `cc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cpf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `validade` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cvv` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `endereco` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `senha_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pedido` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `enc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `parcelas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 233 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of dados
-- ----------------------------

-- ----------------------------
-- Table structure for dados_boletos
-- ----------------------------
DROP TABLE IF EXISTS `dados_boletos`;
CREATE TABLE `dados_boletos`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `produto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `valor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `linha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pedido` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cobrado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `vencimento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pdf` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `endereco` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `numero` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `bairro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cidade` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `estado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `referencia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `doc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `cep` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1',
  `cartId` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5822 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of dados_boletos
-- ----------------------------

-- ----------------------------
-- Table structure for drops
-- ----------------------------
DROP TABLE IF EXISTS `drops`;
CREATE TABLE `drops`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `cpf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `drop` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `endereco` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 300 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of drops
-- ----------------------------

-- ----------------------------
-- Table structure for encurtador
-- ----------------------------
DROP TABLE IF EXISTS `encurtador`;
CREATE TABLE `encurtador`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `produto_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `produto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `clicks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of encurtador
-- ----------------------------

-- ----------------------------
-- Table structure for facebooks
-- ----------------------------
DROP TABLE IF EXISTS `facebooks`;
CREATE TABLE `facebooks`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 200 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of facebooks
-- ----------------------------

-- ----------------------------
-- Table structure for fail
-- ----------------------------
DROP TABLE IF EXISTS `fail`;
CREATE TABLE `fail`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `fail` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of fail
-- ----------------------------
INSERT INTO `fail` VALUES (1, '0');

-- ----------------------------
-- Table structure for historico
-- ----------------------------
DROP TABLE IF EXISTS `historico`;
CREATE TABLE `historico`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `local` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 196 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of historico
-- ----------------------------

-- ----------------------------
-- Table structure for href
-- ----------------------------
DROP TABLE IF EXISTS `href`;
CREATE TABLE `href`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `src` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `init` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of href
-- ----------------------------
-- ----------------------------
-- Table structure for metricas
-- ----------------------------
DROP TABLE IF EXISTS `metricas`;
CREATE TABLE `metricas`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `visitas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `boletos` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `pagamentos_boleto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `pagamentos_pix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `dia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nome_do_dia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `lucro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of metricas
-- ----------------------------
-- ----------------------------
-- Table structure for notify
-- ----------------------------
DROP TABLE IF EXISTS `notify`;
CREATE TABLE `notify`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `mensagem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `lida` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `notificado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `hash` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 452 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notify
-- ----------------------------

-- ----------------------------
-- Table structure for onlines
-- ----------------------------
DROP TABLE IF EXISTS `onlines`;
CREATE TABLE `onlines`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `local` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59852 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of onlines
-- ----------------------------

-- ----------------------------
-- Table structure for pix
-- ----------------------------
DROP TABLE IF EXISTS `pix`;
CREATE TABLE `pix`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `cola` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `img` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `gerados` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `chave` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `codigo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `produto_nome` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `copiados` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `pagos` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of pix
-- ----------------------------

-- ----------------------------
-- Table structure for produtos
-- ----------------------------
DROP TABLE IF EXISTS `produtos`;
CREATE TABLE `produtos`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `valor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `parcelas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `codigo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `valores` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `extra` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `visitas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ficha` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `informacoes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `produto_codigo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `swipe` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `index` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  `cor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `skullid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 240 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of produtos
-- ----------------------------

-- ----------------------------
-- Table structure for sessions
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `session` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `acesso` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1',
  `authy` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 189 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sessions
-- ----------------------------
-- ----------------------------
-- Table structure for smtp
-- ----------------------------
DROP TABLE IF EXISTS `smtp`;
CREATE TABLE `smtp`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `host` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `login` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `senha` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `porta` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `success` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `fail` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  `to` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 139 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of smtp
-- ----------------------------

-- ----------------------------
-- Table structure for visitas
-- ----------------------------
DROP TABLE IF EXISTS `visitas`;
CREATE TABLE `visitas`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `pc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of visitas
-- ----------------------------
INSERT INTO `visitas` VALUES (1, '0', '0');

-- ----------------------------
-- Table structure for x9
-- ----------------------------
DROP TABLE IF EXISTS `x9`;
CREATE TABLE `x9`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `qtd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `empresa` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `acesso` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `local` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of x9
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
