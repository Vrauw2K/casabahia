<?php 
    $config = [
    "admin" => "gestor", //CAMINHO ATÉ O PAINEL ADMIN
    "user_authy" => "astra", //USUÁRIO DE ACESSO DO PAINEL
    "pass_authy" => "Eva@99758579", //SENHA DE ACESSO AO PAINEL
    "mysql_host" => "localhost", //MYSQL HOST / IP
    "mysql_user" => "cbastra1", //MYSQL USUÁRIO
    "mysql_password" => "La@102030", //MYSQL SENHA
    "mysql_dbname" => "cbastra1", //NOME DO BANCO DE DADOS
    "serial" => "12345",
    "senha" => "12345"
];
?>