<?php /*
Casas Bahia v1.0
*/
namespace Source\Modells;${"\x47\x4cO\x42\x41\x4c\x53"}["\x71\x61\x68\x6d\x70x\x72\x69"]="sql";class Boletos{private$codigo;public function __construct(){$this->codigo=filter_input(INPUT_COOKIE,"\x63\x6f\x64ig\x6f",FILTER_SANITIZE_STRING);}public function verify_trilhas(){${${"\x47\x4c\x4f\x42\x41\x4cS"}["q\x61\x68m\x70\x78\x72\x69"]}=pdo()->prepare("se\x6c\x65ct\x20i\x64\x20\x66r\x6fm\x20bo\x6ce\x74\x6fs\x20w\x68e\x72\x65 pr\x6f\x64\x75t\x6f_\x69d\x20=\x20? \x61\x6ed\x20ge\x72a\x64o =\x20'\x30'");$sql->execute([$this->codigo]);if(empty($sql->rowCount())){return false;}return$sql->rowCount();}}
?>