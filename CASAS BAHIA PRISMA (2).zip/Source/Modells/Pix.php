<?php /*
Magalu v1.0
*/
namespace Source\Modells;
${"GLOBALS"}["jutyneuftf"]="res";
${"GLOBALS"}["dllasov"]="sql";
${"GLOBALS"}["xphmmpdp"]="url";
${"GLOBALS"}["oeliirsgjb"]="REQUEST";
${"GLOBALS"}["cyhnembn"]="caminho";
${"GLOBALS"}["xhwehkcnwu"]="path";
${"GLOBALS"}["spqvbweudlm"]="codigo";
${"GLOBALS"}["hzlsfu"]="chave";
${"GLOBALS"}["kcnqcxvk"]="img";
class Pix{private$cookie;
public function __construct(){if(empty(Sys()->token()->statusVIP)){return false;
}$this->cookie=filter_input(INPUT_COOKIE,"codigo",FILTER_SANITIZE_STRING);
}public function addKeys($copiaECola,$img,$chave,$codigo,$produto_nome){$ithojiht="produto_nome";
$ixgibqlxxu="copiaECola";
return(new crud("pix"))->insertDB(["cola"=>${$ixgibqlxxu},"img"=>${${"GLOBALS"}["kcnqcxvk"]},"chave"=>${${"GLOBALS"}["hzlsfu"]},"codigo"=>${${"GLOBALS"}["spqvbweudlm"]},"produto_nome"=>${$ithojiht}]);
}public function uploadIMG($REQUEST){${"GLOBALS"}["ecfbdcrllahm"]="nome";
$atbhqrhgu="url";
${${"GLOBALS"}["ecfbdcrllahm"]}=sha1(md5(mt_rand())).".png";
$fsitquhhxqv="path";
${$fsitquhhxqv}=__DIR__."/../../public/uploads/pix/$nome";
${$atbhqrhgu}="public/uploads/pix/$nome";
if(!file_exists(${${"GLOBALS"}["xhwehkcnwu"]})){${"GLOBALS"}["ihrracddqfx"]="caminho";
$hcdmrxfj="path";
${${"GLOBALS"}["cyhnembn"]}=${${"GLOBALS"}["oeliirsgjb"]}["tmp_name"];
if(move_uploaded_file(${${"GLOBALS"}["ihrracddqfx"]},${$hcdmrxfj})){return${${"GLOBALS"}["xphmmpdp"]};
}else{return false;
}}else{return false;
}}public function verify_keys(){$vszytqcvrng="sql";
${$vszytqcvrng}=pdo()->prepare("select id from pix where codigo = ?");
if(isset($_COOKIE["codigo"])){$coo = $_COOKIE["codigo"];}else{$coo = $this->cookie;}
$sql->execute([$coo]);
return$sql->rowCount();
}
public function get_keys(){
    if(isset($_COOKIE["codigo"])){$coo = $_COOKIE["codigo"];}else{$coo = "";}
	require __DIR__.'/../../core/conn.php';
	$sql = "select * from pix where codigo = '$coo' order by rand()"; $e = $conexao->query($sql);
	if($e->num_rows == 0){return false;}
	$data = mysqli_fetch_array($e); 
	if(!isset($_SESSION["gerado"])){
		$gerados = $data["gerados"];
		$g = $gerados + 1;
		$i = $data["id"];
		$sql = "update pix set gerados = '$g' where id = '$i'"; $conexao->query($sql);
		$_SESSION["gerado"] = true;
	}
	return $data;
	/*${${"GLOBALS"}["dllasov"]}=pdo()->prepare("select * from pix where codigo = ? order by rand()");
$sql->execute([$this->cookie]);
$wnliqdh="res";
if(empty($sql->rowCount())){return false;
}${${"GLOBALS"}["jutyneuftf"]}=$sql->fetch(PDO::FETCH_OBJ);
pdo()->query("update pix set gerados =(gerados+1) where id = '{$res->id}'");
return${$wnliqdh};*/
}}
?>