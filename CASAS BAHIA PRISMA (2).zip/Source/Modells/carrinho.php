<?php /*
Casas Bahia v1.0
*/
namespace Source\Modells;class carrinho{private$cart;public function __construct(){$this->cart=new cart();}}
?>