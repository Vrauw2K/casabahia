<?php /*
Casas Bahia v1.0
*/
namespace Source\Modells;class open{public static function initCartId(){if(!isset($_SESSION["ca\x72\x74I\x64"])){${"\x47\x4cO\x42A\x4cS"}["g\x75vc\x72\x71\x71s\x64\x77\x75"]="\x74";$oochgecbtr="\x74";${$oochgecbtr}=time()+mt_rand();$_SESSION["c\x61rt\x49\x64"]=md5(sha1($_SERVER["\x52\x45\x4d\x4f\x54\x45\x5f\x41D\x44R"].${${"\x47\x4cO\x42\x41\x4cS"}["g\x75\x76\x63r\x71\x71\x73d\x77\x75"]}));}}}
?>